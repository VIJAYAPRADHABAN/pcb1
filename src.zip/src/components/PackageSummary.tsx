import {IOrder} from '../hooks/useWorkflow';
import {StyleSheet, View} from 'react-native';
import { BoldText, RegularText } from './Text/RegularText';
import * as React from 'react';
import PackageInfo from '../interfaces/PackageInfo';

const styles = StyleSheet.create({
  infoLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'space-between',
    fontSize: 14,
  },
  packageInfoContainer: {
    backgroundColor: 'white',
    flexDirection: 'column',
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
});

interface PackageSummaryProps {
  order: IOrder | null;
  packageInfo: PackageInfo | null;
  panelsSent: number;
  serialNumbersSent: string[];
  boardsPerPanel: string;
  p_type: string;
  panelType: string;
}

export const PackageSummary = ({
  order,
  packageInfo,
  panelsSent,
  serialNumbersSent,
  boardsPerPanel,
  p_type,
  panelType,
}: PackageSummaryProps) => {
  return (
    <View>
      <BoldText text={'Package successfully sent!'} styles={{fontSize: 14, textAlign: 'center', paddingBottom:12, color: 'green'}} />


      <BoldText text={'Package details'} styles={{fontSize: 14, textAlign: 'center', paddingBottom:6}} />
      <View style={styles.packageInfoContainer}>
        <View style={styles.infoLine}>
          <RegularText text={'Order number'} />
          <BoldText
              text={`${order?.orderId}`}
          />
        </View>

        <View style={styles.infoLine}>
          <RegularText text={'Product number'} />
          <BoldText
            text={`${order?.productNumber} / ${order?.productRevision}`}
          />
        </View>

        <View style={styles.infoLine}>
          <RegularText text={'Component number'} />
          <BoldText
            text={`${packageInfo?.productNo} / ${packageInfo?.rState}`}
          />
        </View>

        <View style={styles.infoLine}>
          <RegularText text={p_type === 'SINGLE' && panelType=== 'MULTI' ? 'Number of boards per panel' :'Number of panels sent'} />
          <BoldText text={`${panelsSent}`} />
        </View>

        <View style={styles.infoLine}>
          <RegularText text={p_type === 'SINGLE' && panelType=== 'MULTI' ? 'Number of panels sent' : 'Number of boards per panel'} />
          <BoldText text={`${boardsPerPanel}`} />
        </View>

        <View style={styles.infoLine}>
          <RegularText text={'Number of serials sent'} />
          <BoldText text={`${serialNumbersSent.length}`} />
        </View>
      </View>
    </View>
  );
};
