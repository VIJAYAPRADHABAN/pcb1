import ScanResult from '../../interfaces/ScanResult';
import PackageInfo from '../../interfaces/PackageInfo';

export const identifiers = new Map<string, string>([
  ['P', 'productNo'],
  ['21P', 'rState'],
  ['18V', 'factoryCode'],
  ['1P', 'supplierPartNo'],
  ['2P', 'supplierVersion'],
  ['Q', 'quantity'],
  ['11D', 'manufactureDate'],
  ['12D', 'manufactureDate'],
  ['1T', 'batchNumber'],
  ['13E', 'msl'],
  ['4L', 'countryCode'],
]);

export const removeNonASCII = (str: string) => str.replace(/[^\x20-\x7E]/g, '');

export const parsePDF417OrderWithSeparator = (
  pdf417string: string,
  separator: string,
): PackageInfo => {
  const separated = pdf417string.split(separator);
  const keyArr = [...identifiers.keys()];

  return keyArr.reduce((prevVal, currentVal) => {
    const key = currentVal;
    const name = identifiers.get(key);

    let value: string;
    const match = separated.find((x: string) => x.startsWith(key));
    if (!match) {
      value = '';
    } else {
      value = removeNonASCII(match.slice(key.length));
    }

    let res = {[`${name}`]: value};
    // manufactureDate has two keys with same name. Check needed not to overwrite.
    if (name == 'manufactureDate' && prevVal.manufactureDate) {
      res = {};
    }

    return {...prevVal, ...res};
  }, {} as PackageInfo);
};

export const findSeparator = (pdf417string: string): string | null => {
  if (!pdf417string) {
    return null;
  }
  let m = new Map();
  const keyArr = [...identifiers.keys()];

  keyArr.forEach(k => {
    const match = pdf417string.match(`^.*?(.)${k}(?!.*${k})`);
    if (match && match.length) {
      if (m.has(match[1])) {
        let val: number = m.get(match[1]);
        val++;
        m.set(match[1], val);
      } else {
        m.set(match[1], 1);
      }
    }
  });

  let separatorCount = 0;
  let separator = '';
  for (var key of m.keys()) {
    var value: number = m.get(key);
    if (!separatorCount || separatorCount < value) {
      separatorCount = value;
      separator = key;
    }
  }
  if (separatorCount > 7) {
    return separator;
  } else return null;
};

export const parsePDF417OrderWoColons = (
  pdf417string: string,
): PackageInfo | null => {
  var regex =
    '^.*?P(.*)21P(.*)Q(.*)18V(.*)1P(.*)2P(.*)(?:1[1|2]{1}D(.*))1T(.*)13E(.*)4L(.*)$';
  const match = pdf417string.match(regex);

  if (match != null && match.length) {
    const values: string[] = [];
    match.map((m, i) => {
      if (i != 0) {
        values.push(removeNonASCII(m));
      }
    });

    return {
      productNo: values[0],
      rState: values[1],
      quantity: values[2],
      factoryCode: values[3],
      supplierPartNo: values[4],
      supplierVersion: values[5],
      manufactureDate: values[6],
      batchNumber: values[7],
      msl: values[8],
      countryCode: values[9],
    } as PackageInfo;
  } else return null;
};

export const parseCodes128 = (codes: string[]): PackageInfo => {
  const keyArr = [...identifiers.keys()];

  return keyArr.reduce((prevVal, currentVal) => {
    const key = currentVal;
    const name = identifiers.get(key);

    let value: string;
    const match = codes.find((x: string) => x.startsWith(key));
    if (!match) {
      value = '';
    } else {
      value = match.slice(key.length);
    }

    let res = {[`${name}`]: value};
    // manufactureDate has two keys with same name. Check needed not to overwrite.
    if (name == 'manufactureDate' && prevVal.manufactureDate) {
      res = {};
    }

    return {...prevVal, ...res};
  }, {} as PackageInfo);
};

export const parseAndValidatePackageScanResult = (
  scanResult: ScanResult[],
): PackageInfo => {
  const pfd417Codes = scanResult
    .filter(x => x.type == 'pdf417')
    .map(y => y.data);
  const code128Codes = scanResult
    .filter(x => x.type == 'code128')
    .map(y => y.data);
  if (pfd417Codes.length == 0 && code128Codes.length == 0) {
    throw Error('No codes Scanned. Try again');
  }

  const pfd417Code = pfd417Codes[0];
  let packageInfoPdf417: PackageInfo | null = null;
  if (pfd417Code) {
    const separator = findSeparator(pfd417Code);
    packageInfoPdf417 = separator
      ? parsePDF417OrderWithSeparator(pfd417Code, separator)
      : parsePDF417OrderWoColons(pfd417Code);
  }

  const packageInfoCode128 = parseCodes128(code128Codes);

  if (packageInfoPdf417 === null) {
    return packageInfoCode128;
  }

  const res = {} as PackageInfo;

  for (const [keyPdf417, valuePdf417] of Object.entries(packageInfoPdf417)) {
    const key = keyPdf417 as keyof PackageInfo;
    const valueCode128 = packageInfoCode128[key];
    if (valueCode128 !== '' && valueCode128 !== valuePdf417) {
      res[key] = '';
    } else {
      res[key] = valuePdf417;
    }
  }

  return res;
};

export const filterScanned = (
  newSerials: ScanResult[],
  scanned: string[],
  sent: string[],
): string[] => {
  const regex = "^.*?S(?=E)(.*)$"
  const dataMatrixSerials = newSerials.filter(x => x.type == 'dataMatrix');
  const sortedDataMatrixSerials = dataMatrixSerials.map(x =>x.data);

  const filteredDataMatrixSerials = [] as string[];
  sortedDataMatrixSerials.forEach(s => {
    const match = s.match(regex)
    if(match != null && match.length == 2){
      filteredDataMatrixSerials.push(removeNonASCII(match[1]))
    }
  })

  const serialsWoAlreadyScanned = filteredDataMatrixSerials.filter(
    x => !scanned.some(y => y === x),
  );

  const serialsWoSent = serialsWoAlreadyScanned.filter(
    x => !sent.some(z => z === x),
  );

  return serialsWoSent.sort();
};
