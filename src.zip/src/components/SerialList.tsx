import React, {Dispatch, ReducerAction, useEffect, useState} from 'react';
import {View, Image, FlatList, TouchableOpacity} from 'react-native';
import SerialNoOptions from '../components/SerialNoOptions';
import {serialListStyles} from '../assets/componentStyles';
import {RegularText} from './Text/RegularText';
import {infoAlert} from './PackageInfoDetails';
import {OrderIcon} from '../assets/OrderIcon';
import {PackageSummary} from './PackageSummary';
import {
  WorkflowAction,
  WorkflowReducerState,
} from '../hooks/reducers/workflowReducer';

export interface SerialListProps {
  dispatch: Dispatch<ReducerAction<any>>;
  workflowState: WorkflowReducerState;
  logging: {
    sendErrorLog: (error: string) => void;
    sendWarningLog: (error: string) => void;
    sendInfoLog: (error: string) => void;
  };
  resetWorkflow: () => void;
}

const getHeader = () => {
  const styles = serialListStyles;

  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#878787',
      }}>
      <View style={styles.headerBox}>
        <RegularText text={'Board'} styles={{fontSize: 14}} />
        <OrderIcon
          fill={'black'}
          height={13.6}
          width={8}
          styles={styles.sortIcon}
        />
      </View>

      <View style={styles.headerBox}>
        <RegularText text={'S/N'} styles={{fontSize: 14}} />
        <OrderIcon
          fill={'black'}
          height={13.6}
          width={8}
          styles={styles.sortIcon}
        />
      </View>
    </View>
  );
};

interface Serial {
  serialNumber: string;
  panelNo: number;
}

const SerialList = ({
  dispatch,
  workflowState,
  logging,
  resetWorkflow,
}: SerialListProps) => {
  const styles = serialListStyles;
  const {
    serialNumbers,
    sentSerialNumbersForPackage,
    boardNumberPerPanel,
    packageInfo,
    panelsSentForPackage,
    allSentSerials,
    order,
    noOfTimesScan,
    p_type,
    panelType,
  } = workflowState;

  const [data, setData] = useState<any>([]);
  const [selectedSerialNo, setSelectedSerialNo] = useState<Serial | null>(null);

  const getPanelNoForSentSerial = (item: string) => {
    let panels = [];

    for (
      let i = 0;
      i < sentSerialNumbersForPackage.length;
      i += Number(boardNumberPerPanel)
    ) {
      let panel = sentSerialNumbersForPackage.slice(
        i,
        i + Number(boardNumberPerPanel),
      );
      panels.push(panel);
    }

    let panelNo = 1;
    panels.forEach((panel, index) => {
      if (panel.includes(item)) {
        panelNo = index + 1;
      }
    });
    return panelNo;
  };

  const renderItem = ({item, index}: any) => (
    <View style={index % 2 === 0 ? styles.oddItem : styles.evenItem}>
      <View style={styles.rowItem}>
        <View style={styles.indexCol}>
          <RegularText
            styles={{fontSize: 14}}
            text={`${
              panelsSentForPackage === Number(packageInfo?.quantity)
                ? getPanelNoForSentSerial(item)
                : index + 1
            }`}
          />
        </View>

        <View style={styles.codeCol}>
          <RegularText styles={{fontSize: 14}} text={`${item}`} />
        </View>

        {panelsSentForPackage !== Number(packageInfo?.quantity) && (
          <TouchableOpacity
            onPress={() =>
              setSelectedSerialNo({serialNumber: item, panelNo: index + 1})
            }>
            <Image
              source={require('../assets/logo/menu.png')}
              style={styles.icon}
            />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  const deleteSerialNo = (serialNo: string) => {
    const newSerialNumbers = serialNumbers.filter(s => s !== serialNo);

    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'serialNumbers', value: newSerialNumbers},
    });

    setSelectedSerialNo(null);
  };

  useEffect(() => {
    initData();
  }, []);

  useEffect(() => {
    initData();
  }, [serialNumbers]);

  const initData = () => {
    const _boardNumberPerPanel = parseInt(boardNumberPerPanel);

    setData(serialNumbers.slice(0, _boardNumberPerPanel));
    dispatch({
      type: WorkflowAction.Set,
      payload: {
        property: 'okToSendSerials',
        value: serialNumbers.length >= _boardNumberPerPanel,
      },
    });
  };

  useEffect(() => {
    if (panelsSentForPackage === Number(noOfTimesScan)) {
        infoAlert(
          'Order processed!',
          'All serials for current order sent!',
          resetWorkflow,
          () => {},
        );
        logging.sendInfoLog(`"message": 'All serials for current order sent!'`);
    }
  }, [ panelsSentForPackage]);

  return (
    <View style={styles.container}>
      <View style={styles.textContainer}>
        <View style={styles.textColumn}>
          <RegularText styles={{color: '#6A6A6A'}} text={'Order'} />

          <RegularText styles={{fontSize: 14}} text={`${order?.orderId}`} />
        </View>

        <View style={styles.textColumn}>
          <RegularText styles={{color: '#6A6A6A'}} text={'R-state'} />

          <RegularText
            styles={{fontSize: 14}}
            text={`${packageInfo?.rState}`}
          />
        </View>

        <View style={styles.textColumn}>
          <RegularText styles={{color: '#6A6A6A'}} text={'Product number'} />

          <RegularText
            styles={{fontSize: 14}}
            text={`${packageInfo?.productNo}`}
          />
        </View>
      </View>

      <View style={styles.listContainer}>
        {panelsSentForPackage === Number(noOfTimesScan) ? (
          <PackageSummary
            order={order}
            packageInfo={packageInfo}
            panelsSent={panelsSentForPackage}
            serialNumbersSent={sentSerialNumbersForPackage}
            boardsPerPanel={boardNumberPerPanel}
            p_type={p_type}
            panelType={panelType}
          />
        ) : (
          <FlatList
            data={data}
            renderItem={renderItem}
            keyExtractor={(item, index) => item + index}
            ListHeaderComponent={getHeader}
          />
        )}
      </View>
      {panelsSentForPackage !== Number(noOfTimesScan) &&
        selectedSerialNo?.serialNumber &&
        selectedSerialNo?.serialNumber.length > 0 && (
          <SerialNoOptions
            serialNo={selectedSerialNo.serialNumber}
            panelNo={selectedSerialNo.panelNo}
            deleteSerialNo={deleteSerialNo}
            hide={() => setSelectedSerialNo(null)}
          />
        )}
    </View>
  );
};

export default SerialList;
