import React from 'react';

import {
  Camera,
  CameraSettings,
  DataCaptureContext,
  FrameSourceState,
  VideoResolution,
} from 'scandit-react-native-datacapture-core';

import {
  BarcodeCapture,
  BarcodeCaptureSettings,
  BarcodeTracking,
  BarcodeTrackingSettings,
  Symbology,
} from 'scandit-react-native-datacapture-barcode';

import MultiScan from './MultiScan';

import ScanResult from '../interfaces/ScanResult';
import SingleScan from './SingleScan';
import {Platform} from 'react-native';

export interface ScanHookProps {
  setCode: any;
  isMultiScan?: boolean;
  amountToScan?: string;
  enableSymbologies: Symbology[];
  continueOnAmountReached: boolean;
  scannedSerials?: any[];
  allSentSerials?: string[];
  scanDone: boolean;
}

const ScanHook: React.FC<ScanHookProps> = ({
  setCode,
  isMultiScan = false,
  amountToScan,
  enableSymbologies,
  continueOnAmountReached,
  scannedSerials,
  allSentSerials,
  scanDone,
}) => {
  React.useEffect(() => {
    start();
  });
  const activeSymbolCount = [4, 5, 6,  7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
    23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
  ];

  const [startMultiScan, setStartMultiScan] = React.useState<boolean>(false);

  const [camera] = React.useState<Camera | null>(Camera.default);

  const androidLicenseKey =
    'AY7w5L6BKrCYAbjarPAilRI8kliFRHQqBlyihMB24AvydONO9mwRAqdbMSdvbRnzcFFByB58npZVK6cm1GircQVcnz95av7QzD+FhnlXY4kuLR3m3iecwi5DEjvITveHv3kslfhCZWHrXgn7rHAwHwkpqSnnDrdJcQugHj8Uj6z9rUsZHmyqT3kCBBZW4aA+Cj+QYFRzgdxYoG+2xZ2wo+08N9YEO31AmLpqRdbNyEHTvcTII2A+IVHnS6sBVKaN04Wk3GWC46+P9+IPW2ISC55BSSroCq/cJkcsizOCNJlhab32o8w9vwfjO5PwMPT1j0uO95nyX/gIGHKCTQIQ7B3Onx4fA2/+MNRUxX3fqQcziy6eUrBLmTuVOWFF0W4Vf2DWkY4nXSuVJvNWDNB8KaxthW1pEWDvEZpcofN65zyddV3liyQS8WK5+O+3bhxY8np+pB8FnVnK+NN437JuWlLRtCB5dqdT5GS64x23V6/j4+N2lvYK9zxdc0e0LQeWAphvRxisfjQjTXy2FmVpi819BD/5m4PHBykLtCUR9tD8nV3rqxQatKzAhv0JiyKtGYp2m4/XRX5S/gfZp4/k+ECg2KhALtcTQmh6dPyeplHHVltegK6lnDPpwJkGCCyKg3uPfWbmcq2p4lM7mp5BIGEnA2tL5OVLC1ScYFRIqJpFBO/TpiKtV59rnkE5d7BOJkI6AgEYJ75mjyh+XTWqDhtyZDMFE8oKCk12SqlitaZTVXyYBAAs+eiieZbxYlcgxi/wLVMhiThPrEnbcX/SfavWuAF0s7cbXil4Rh0okng/KPiMZWIpRGoWIG4dhAWy0d5HcQUXnwzilv2Egdgubw==';
  const iosLicenseKey =
    'AUwQBIOBF73yPiJAePQWxJ0RXTJbWbqugEkEADRalHEfWI5rtn0hI5FNJ67ZTwBEgWT/czps9s+oUGemoGSVkP1OCEKlVpLwHjw37Q1IdxKtRV671Xkna8NcDy1NamIKb3QMKZVlyJosev6R9lQ6pDVGtRzOJl6d4gdD6Tgr2BsosoTiUw2YIySbjONrXDzNWVEXxkdj53WMoPfCurJwk4n6w6OcmtMsJXAhsdygNEvgpTrZyhJ8yNlAu8kWVBAvV1Kr2ePlx418Lh/9BTc3XZthTbqVAxhPWsX1ieNfrdkwLEBU5eOopPg0ks8WbyFtpmMizWZq9OT8Zp0Zi/ywZmNUdBf+q4wXq7oSevGT1FcKIun/jsVvjn45t6sBocaoRmS/B2e4vYOmwUVPKMFGZ+L4d+U+21X4yMwj+JCP7fh5nFu3XT3HBnZb0TksSXccyu4h8NMnVkI3bVRhIyhGuHbBvu296b7eTc273cmVz2GG1w6hW5aza8QQq7r4R5Gjq7A9xVgNaeNvTI/MIpYI0a8sRqbjbbwRMl9OmSRby9dshQx9f+1lK+U6c0/DE94j7058jdlALrob6f4/RAZG6C8U0ylH5S4IyyXbAHH0kVfOGngQ8S40IJYcUq65wyMp6CB9XdvMacQ72rEt8UD9bVY/vHwdXI3A3WV84N3eb5Ai6gZDGMhCxe1i9x064UZ4LM/RQYtJRKIpGxmFOciQU3emmuGGAHSmKWrhe9YueYV26C0C0vss5uzB52NcLMWYq9WspBPZkhrWXK3Gm+Cpt7fq0Aex0ogvaM9kepbPmZ4POuDvrgf0961VCgeORz0yN5uNNvscRe6gsj3hrr4+1g==';

  const dcc = DataCaptureContext.forLicenseKey(
    Platform.OS === 'ios' ? iosLicenseKey : androidLicenseKey,
  );
  const [dataCaptureContext] = React.useState<DataCaptureContext>(dcc);

  const cameraSettings = new CameraSettings();
  cameraSettings.preferredResolution = VideoResolution.FullHD;
  camera?.applySettings(cameraSettings);
  camera?.switchToDesiredState(FrameSourceState.Off);

  dataCaptureContext.setFrameSource(camera);

  const trackingSettings = new BarcodeTrackingSettings();

  trackingSettings.enableSymbologies([...enableSymbologies]);

  const symbologySettingsMultiScan = trackingSettings.settingsForSymbology(
    Symbology.Code128,
  );
  symbologySettingsMultiScan.activeSymbolCounts = activeSymbolCount;

  // Create new barcode tracking mode with the settings from above.
  const [barcodeTracking] = React.useState<BarcodeTracking>(
    BarcodeTracking.forContext(null, trackingSettings),
  );

  const captureSettings = new BarcodeCaptureSettings();

  captureSettings.enableSymbologies([...enableSymbologies]);

  const symbologySettings = captureSettings.settingsForSymbology(
    Symbology.Code128,
  );

  symbologySettings.activeSymbolCounts = activeSymbolCount;

  const [barcodeCapture] = React.useState<BarcodeCapture>(
    BarcodeCapture.forContext(null, captureSettings),
  );

  const removeAllModes = () => {
    dataCaptureContext.removeAllModes();
  };

  const addBarcodeCaptureMode = () => {
    dataCaptureContext.addMode(barcodeCapture);
  };

  const addBarcodeTrackingMode = () => {
    dataCaptureContext.addMode(barcodeTracking);
  };

  const start = () => {
    setStartMultiScan(false);
  };

  const stop = () => {
    setStartMultiScan(false);
  };

  const multiScanSuccess = (codes: ScanResult[]) => {
    setCode(codes);
    stop();
  };

  const singleScanSuccess = (code: ScanResult) => {
    setCode(code);
    stop();
  };

  return (
    <>
      {isMultiScan ? (
        <MultiScan
          continueOnAmountReached={continueOnAmountReached}
          onClose={stop}
          onSuccess={multiScanSuccess}
          barcodeTracking={barcodeTracking}
          addBarcodeTrackingMode={() => {
            addBarcodeTrackingMode();
          }}
          removeAllModes={() => {
            removeAllModes();
          }}
          amountToScan={amountToScan}
          allSentSerials={allSentSerials}
          scannedSerials={scannedSerials}
          scanDone={scanDone}
        />
      ) : (
        <SingleScan
          barcodeCapture={barcodeCapture}
          addBarcodeCaptureMode={() => {
            addBarcodeCaptureMode();
          }}
          removeAllModes={() => {
            removeAllModes();
          }}
          onSuccess={singleScanSuccess}
          scanDone={scanDone}
        />
      )}
    </>
  );
};

export default ScanHook;
