import PackageInfo from './../interfaces/PackageInfo';

import ScanHook from './ScanHook';
import {parseAndValidatePackageScanResult} from './MultiScan/MultiScanHelpers';
import ScanResult from '../interfaces/ScanResult';
import {Symbology} from 'scandit-react-native-datacapture-barcode';
import React from 'react';
import {alertError} from './PackageInfoDetails';

export interface ProdOrderValidateProps {
  setParsedPackageInfo: (value: PackageInfo | null) => void;
  scanDone: boolean;
  logging: {
    sendErrorLog: (error: string) => void;
    sendWarningLog: (error: string) => void;
    sendInfoLog: (error: string) => void;
  };
  handlePackageScanError: () => void;
}

const ProdOrderValidate: React.FC<ProdOrderValidateProps> = ({
  setParsedPackageInfo,
  scanDone,
  logging,
  handlePackageScanError,
}) => {
  const parseCode = (scanResult: ScanResult[]) => {
    try {
      const packageInfo = parseAndValidatePackageScanResult(scanResult);
      if (!packageInfo) {
        logging.sendWarningLog(
          `"message": "package info null after parsing. ScanResult: ${encodeURIComponent(
            JSON.stringify(scanResult),
          )}"`,
        );
        return;
      }
      setParsedPackageInfo(packageInfo);
    } catch (error) {
      logging.sendErrorLog(
        `"message": "error on parsing and validating PackageScanResult ${error}. ScanResult: ${encodeURIComponent(
          JSON.stringify(scanResult),
        )}"`,
      );
      alertError('Failed to parse codes', error);
      handlePackageScanError();
    }
  };

  return (
    <ScanHook
      continueOnAmountReached={false}
      amountToScan="12"
      isMultiScan
      setCode={parseCode}
      enableSymbologies={[Symbology.PDF417, Symbology.Code128]}
      scanDone={scanDone}
    />
  );
};

export default ProdOrderValidate;
