import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Platform} from 'react-native';
import EdsButton from './Button/EdsButton';
import User from '../interfaces/User';
import {BoldText} from './Text/RegularText';
import {EricssonLogo} from '../assets/logo/EricssonLogo';

const iosStyles = StyleSheet.create({
  textInput: {
    marginTop: 32,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: 'center',
    backgroundColor: '#EBEBEB',
  },
  input: {
    height: 40,
    marginVertical: 12,
    borderWidth: 1,
    paddingHorizontal: 5,
    backgroundColor: 'white',
    borderColor: '#878787',
  },
  saveButtonContainer: {
    marginTop: 12,
  },
  logo: {
    height: 31,
  },
});

const androidStyles = StyleSheet.create({
  textInput: {
    marginTop: 17,
    marginBottom: 32,
    fontSize: 18,
    lineHeight: 27,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    backgroundColor: '#EBEBEB',
  },
  input: {
    fontFamily: 'EricssonHilda-Regular',
    fontSize: 14,
    lineHeight: 21,
    color: 'black',
    borderColor: '#878787',
    height: 40,
    marginVertical: 12,
    borderWidth: 1,
    minWidth: 40,
    textAlign: 'left',
    backgroundColor: 'white',
  },
  saveButtonContainer: {
    marginTop: 12,
  },
});

const superUsers: string[] = [
  'idm-esst-ssml-superuser',
  'idm-esst-ssml-test-superuser',
  'idm-enc-ssml-superuser',
  'idm-efa-ssml-superuser',
  'idm-edb-ssml-superuser',
];

export const hasSuperUserPermissions = (user: User): boolean => {
  return user.roles.some((role: string) => superUsers.includes(role));
};

export interface LoginProps {
  login: (userId: string, password: string) => void;
}

const Login: React.FC<LoginProps> = ({login}) => {
  const [userId, setUserId] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const styles = Platform.OS === 'ios' ? iosStyles : androidStyles;

  const _login = () => {
    login(userId, password);
  };

  return (
    <View style={styles.container}>
      <View>
        <EricssonLogo height={56} width={41.46} fill="#000000" />
      </View>
      <BoldText styles={styles.textInput} text={'PCBTrace Manual Scanner'} />
      {/* <TextInput
        style={styles.input}
        onChangeText={setUserId}
        value={userId}
        placeholder="Username"
        placeholderTextColor="#6A6A6A"
      />
      <TextInput
        onChangeText={setPassword}
        value={password}
        placeholder="Password"
        style={styles.input}
        placeholderTextColor="#6A6A6A"
        secureTextEntry={true}
      /> */}
      <View style={styles.saveButtonContainer}>
        <EdsButton
          onPress={_login}
          title="Loginn"
          color="#1174E6"
          width="100%"
          buttonType="primary"
        />
      </View>
    </View>
  );
};

export default Login;
