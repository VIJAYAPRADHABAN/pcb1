import React from 'react';
import {TouchableOpacity, TextStyle, View} from 'react-native';
import styles from './ButtonStyles';
import {RegularText} from '../Text/RegularText';
export interface ButtonProps {
  title: string;
  onPress?: any;
  buttonType?: string;
  width?: number | string;
  fontSize?: number;
  isDisabled?: boolean;
  textColor?: string;
  align?: string;
  [otherProps: string]: any;
}
function btnStyle(_btnType: string): TextStyle {
  let result = styles.primary;
  switch (_btnType) {
    case 'warning':
      result = styles.warning;
      break;
    case 'secondary':
      result = styles.secondary;
      break;
    default:
      styles.primary;
      break;
  }
  return result;
}
const EdsButton: React.FC<ButtonProps> = ({
  title,
  onPress,
  buttonType = 'primary',
  width,
  fontSize,
  isDisabled,
  textColor,
  align,
  otherProps,
}) => {
  return (
    <TouchableOpacity
      style={[
        btnStyle(buttonType),
        styles.button,
        {width: width},
        isDisabled ? styles.disabled : '',
        align ? {alignSelf: align} : '',
      ]}
      disabled={isDisabled}
      onPress={onPress}
      {...otherProps}>
      <View>
        <RegularText
          text={title}
          styles={{
            fontSize: fontSize ? fontSize : 14,
            lineHeight: 20,
            ...styles.buttonTxtStyle,
            color: textColor ? textColor : '#f2f2f2',
          }}
        />
      </View>
    </TouchableOpacity>
  );
};

export default EdsButton;
