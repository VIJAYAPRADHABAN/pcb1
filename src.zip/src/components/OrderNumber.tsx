import React, {Dispatch, ReducerAction} from 'react';
import {View, TextInput} from 'react-native';
import {orderNumberStyled} from '../assets/componentStyles';
import {RegularText} from './Text/RegularText';
import {EricssonNumberPicker} from './EricssonNumberPicker';
import {
  WorkflowAction,
  WorkflowReducerState,
} from '../hooks/reducers/workflowReducer';

export interface OrderNumberProps {
  workflowState: WorkflowReducerState;
  dispatch: Dispatch<ReducerAction<any>>;
}

const OrderNumber: React.FC<OrderNumberProps> = ({workflowState, dispatch}) => {
  const styles = orderNumberStyled;
  const {orderNumber, lineNumber} = workflowState;

  const onChangeOrderNumber = (value: string) =>
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'orderNumber', value: value},
    });

  const setLineNumber = (value: string) =>
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'lineNumber', value: value},
    });

  return (
    <View style={styles.container}>
      <RegularText styles={styles.textStyles} text={'Compass order number'} />
      <TextInput
        style={styles.input}
        onChangeText={onChangeOrderNumber}
        value={orderNumber}
        placeholder="Enter compass order number"
        placeholderTextColor="#6A6A6A"
      />

      <RegularText styles={styles.textStyles} text={'Line number'} />
      <EricssonNumberPicker
        value={lineNumber}
        onChange={(value: number | string) => setLineNumber(`${value}`)}
      />
    </View>
  );
};

export default OrderNumber;
