import React, {useEffect, useState} from 'react';
import {StyleSheet, TextInput, View} from 'react-native';
import Settings from '../interfaces/Settings';
import EdsButton from './Button/EdsButton';
import CheckBox from '@react-native-community/checkbox';
import {hasSuperUserPermissions} from './Login';
import User from '../interfaces/User';
import {RegularText} from './Text/RegularText';
import {infoAlert} from './PackageInfoDetails';
import {WorkflowState} from '../hooks/reducers/workflowReducer';

const styles = StyleSheet.create({
  textInput: {
    paddingHorizontal: 12,
  },
  container: {
    marginTop: 32,
    flex: 1,
    backgroundColor: '#EBEBEB',
  },
  input: {
    height: 40,
    marginVertical: 12,
    borderWidth: 1,
    paddingHorizontal: 5,
    backgroundColor: 'white',
    borderColor: '#878787',
    fontFamily: 'EricssonHilda-Regular',
    margin: 12,
    color: 'black',
  },
  saveButtonContainer: {
    marginTop: 12,
    paddingHorizontal: 12,
  },
  checkboxContainer: {
    flex: 1,
    maxHeight: 50,
    marginHorizontal: 12,
  },
});

export interface ChangeSettingsProps {
  settings: Settings;
  user: User | null;
  saveSettings: (settings: Settings) => void;
  previousWorkflowState: WorkflowState;
  setWorkflowState: (state: WorkflowState) => void;
}

const ChangeSettings: React.FC<ChangeSettingsProps> = ({
  settings,
  user,
  saveSettings,
  previousWorkflowState,
  setWorkflowState,
}) => {
  const [endpoint, setEndpoint] = useState<string>('');
  const [authEndpoint, setAuthEndpoint] = useState<string>('');
  const [alternativeReportEndpointEnabled, setEnableAlternativeReportEndpoint] =
    useState<boolean>(settings.alternativeReportEndpointEnabled);

  useEffect(() => {
    setEndpoint(settings.endpoint);
    setAuthEndpoint(settings.authEndpoint);
  }, []);

  const save = () => {
    const proceedFunction = () => {
      saveSettings({
        endpoint: endpoint,
        authEndpoint: authEndpoint,
        alternativeReportEndpointEnabled: alternativeReportEndpointEnabled,
      });

      const newState =
        previousWorkflowState === WorkflowState.Unauthenticated && !!user
          ? WorkflowState.OrderNumber
          : previousWorkflowState;
      setWorkflowState(newState);
    };

    const wasApiChangedFromExistingValue =
      endpoint !== settings.endpoint && settings.endpoint?.length > 0;
    const wasAuthEndpointChangedFromExistingValue =
      authEndpoint !== settings.authEndpoint &&
      settings.authEndpoint.length > 0;

    const shouldShowSaveAlert =
      wasApiChangedFromExistingValue || wasAuthEndpointChangedFromExistingValue;

    if (shouldShowSaveAlert) {
      infoAlert(
        'Alert',
        'You are trying to change already defined urls. Are you sure you wish to proceed?',
        proceedFunction,
        () => {},
      );
    } else {
      proceedFunction();
    }
  };

  return (
    <View style={styles.container}>
      {user && hasSuperUserPermissions(user) && (
        <>
          <RegularText styles={styles.textInput} text={'Endpoint'} />
          <TextInput
            testID="api-endpoint-field"
            style={styles.input}
            onChangeText={setEndpoint}
            value={endpoint}
            placeholder="Enter endpoint"
            placeholderTextColor="#6A6A6A"
          />
        </>
      )}

      <RegularText styles={styles.textInput} text={'Auth endpoint'} />
      <TextInput
        testID="auth-endpoint-field"
        style={styles.input}
        onChangeText={setAuthEndpoint}
        value={authEndpoint}
        placeholder="Enter auth endpoint"
        placeholderTextColor="#6A6A6A"
      />

      {user && hasSuperUserPermissions(user) && (
        <>
          <View style={styles.checkboxContainer}>
            <RegularText
              text={'Enable alternative endpoint for sending report'}
            />
            <CheckBox
              testID="alternative-report-enable-checkbox"
              tintColors={{true: '#0069C2', false: '#0069C2'}}
              disabled={false}
              value={alternativeReportEndpointEnabled}
              onValueChange={newValue =>
                setEnableAlternativeReportEndpoint(newValue)
              }
            />
          </View>
        </>
      )}

      <View style={styles.saveButtonContainer}>
        <EdsButton
          testID="save-button"
          onPress={save}
          title="Save"
          color="#1174E6"
          buttonType="primary"
        />
      </View>
    </View>
  );
};

export default ChangeSettings;
