import React, {Dispatch, ReducerAction, useEffect, useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {amountOfBoardsStyles} from '../assets/componentStyles';
import {BoldText, RegularText} from './Text/RegularText';
import {EricssonNumberPicker} from './EricssonNumberPicker';
import {
  WorkflowAction,
  WorkflowReducerState,
} from '../hooks/reducers/workflowReducer';

export interface AmountOfBoardsProps {
  workflowState: WorkflowReducerState;
  dispatch: Dispatch<ReducerAction<any>>;
}

const AmountOfBoards: React.FC<AmountOfBoardsProps> = ({
  workflowState,
  dispatch,
}) => {
  const[single, setSingle]= useState<boolean>(true);
  const[multi, setMulti]= useState<boolean>(false);
  const[divisor, setDivisor]= useState<number[]>([]);
  const[indexValue, setIndexValue]= useState<number>(0);

  const styles = amountOfBoardsStyles;
  const {boardNumberPerPanel, order, packageInfo, panelType, p_type} = workflowState;

  const onBoardNumberChange = (value: string | number, index: number) => {

      if( Number(value) === 1){
        setMulti(false);
        setSingle(true);
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'panelType', value: 'SINGLE' },
        }); 
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'boardType', value: 'SINGLE' },
        }); 
      }else{
        setMulti(true);
        setSingle(false);
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'boardType', value: 'MULTI' },
        }); 
        if(p_type === 'SINGLE'){
          dispatch({
            type: WorkflowAction.Set,
            payload: {property: 'panelType', value: 'MULTI' },
          }); 
        }else{
          dispatch({
            type: WorkflowAction.Set,
            payload: {property: 'panelType', value: 'SINGLE' },
          }); 
        }
      }
      let orderQuantity = Number(order?.quantity);
      let packageQuantity = Number(packageInfo?.quantity);
      let quotientValue;
      if(packageQuantity < orderQuantity){
        quotientValue = packageQuantity / Number(value);
      }else{
        quotientValue = orderQuantity / Number(value);
      }
      setIndexValue(index);
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'noOfTimesScan', value: `${quotientValue}`},
      });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'boardNumberPerPanel', value: `${value}`},
    });
  };

  const singleAction =()=>{
    setIndexValue(0);
    setSingle(true);
    setMulti(false);
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'boardType', value: 'SINGLE' },
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'panelType', value: 'SINGLE' },
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'boardNumberPerPanel', value: 1 },
    });
  }

  const multiAction =()=>{
    if(Number(boardNumberPerPanel) != 1){
      setMulti(true);
      setSingle(false);
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'boardType', value: 'MULTI' },
      });
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'panelType', value: 'MULTI' },
      });
    }else{
      setSingle(true);
      setMulti(false);
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'boardType', value: 'SINGLE' },
      }); 
    }
  }

  useEffect(()=>{
    if(boardNumberPerPanel == '1'){
      setSingle(true);
      setMulti(false);
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'boardType', value: 'SINGLE' },
      });
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'noOfTimesScan', value: packageInfo?.quantity},
      });
    }
  },[boardNumberPerPanel])

  useEffect (()=>{
  let orderQuantity = Number(order?.quantity);
  let packageQuantity = Number(packageInfo?.quantity);
  if(packageQuantity < orderQuantity){
    for(let i = 1; i <= packageQuantity; i++) {
      // check if number is a factor
      if(packageQuantity % i == 0 && !divisor.includes(i)) {
        setDivisor(divisor => [...divisor, i]);
      }
    }
  }else{
    for(let i = 1; i <= orderQuantity; i++) {
      // check if number is a factor
      if(orderQuantity % i == 0 && !divisor.includes(i)) {
        setDivisor(divisor => [...divisor, i]);
      }
    }
  }
    
  },[])

  const renderItem = ({ item, index }) => (
    <>
    {item <= 15 && (
      <>
      {indexValue === index ? (
        <View style={styles.selectedTile}>
          <Text style={{textAlign:'center', color:'#fff'}}>{item}</Text>
        </View>
      ):(
        <TouchableOpacity onPress={()=>onBoardNumberChange(item, index)} style={styles.unselectedTile}>
        <Text style={{textAlign:'center'}}>{item}</Text>
        </TouchableOpacity>
      )}
      </>
      )}
    </>
  );

  return (
    <View style={styles.container}>
      <BoldText
        styles={styles.textStyles}
        text={p_type === 'SINGLE' && multi ?  'Qty of board' : 'Amount of S/N on one board'}
      />
      {p_type === 'SINGLE' ?(
        <View style={{alignItems:'center'}}>
          <FlatList 
          data={divisor}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          />
        </View>
      ): (
      <EricssonNumberPicker
        value={boardNumberPerPanel }
        onChange={onBoardNumberChange}
        panelType={panelType}
      />
      )}

      <BoldText styles={styles.textStyles} text={'Current package info'} />

      <View style={styles.packageInfoContainer}>
        <View style={styles.infoLine}>
          <RegularText text={'Product number'} />
          <RegularText
            text={`${order?.productNumber} / ${order?.productRevision}`}
          />
        </View>

        <View style={styles.infoLine}>
          <RegularText text={'Component number'} />
          <RegularText
            text={`${packageInfo?.productNo} / ${packageInfo?.rState}`}
          />
        </View>
      </View>
      {p_type === 'SINGLE' &&(
        <View style={styles.scanToggleContainer}>
        <TouchableOpacity onPress={singleAction} style={{paddingRight:5}}>
          {single ?(
            <View style={styles.selectedViewStyle}>
              <Text style={styles.selectedTextStyle}>   One Board   </Text>
            </View>
          ):(
            <View style={styles.unselectedViewStyle}>
                <Text style={styles.unselectedTextStyle}>   One Board   </Text>
            </View>
          )}
          </TouchableOpacity>
          <TouchableOpacity onPress={multiAction}>
          {multi ?(
            <View style={styles.selectedViewStyle}>
                <Text style={styles.selectedTextStyle}>Several Boards</Text>
            </View>
          ):(
            <View style={styles.unselectedViewStyle}>
                <Text style={styles.unselectedTextStyle}>Several Boards</Text>
            </View>
          )}
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

export default AmountOfBoards;
