import * as React from 'react';
import {Text} from 'react-native';

export const RegularText = ({
  text,
  styles = {},
}: {
  text: string;
  styles?: any;
}) => {
  return (
    <Text
      style={{
        fontSize: 12,
        lineHeight: 18,
        ...styles,
        fontFamily: 'EricssonHilda-Regular',
      }}>
      {text}
    </Text>
  );
};

export const BoldText = ({text, styles = {}}: {text: string; styles?: any}) => {
  return (
    <Text
      style={{
        fontSize: 12,
        lineHeight: 18,
        ...styles,
        fontFamily: 'EricssonHilda-Bold',
      }}>
      {text}
    </Text>
  );
};
