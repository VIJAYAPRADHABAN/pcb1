import InputSpinner from 'react-native-input-spinner';
import {ChevronUpIcon} from '../assets/ChevronUpIcon';
import {ChevronDownIcon} from '../assets/ChevronDownIcon';
import {View} from 'react-native';
import React from 'react';
import {RegularText} from './Text/RegularText';

const Spacer = () => <View style={{width: 20, height: 20}}></View>;

interface EricssonNumberPickerProps {
  value: number | string;
  panelType: string;
  onChange: (value: number | string, index: number) => void;
}

export const EricssonNumberPicker = ({
  value,
  panelType,
  onChange,
}: EricssonNumberPickerProps) => {
  return (
    <View
      style={{
        flexDirection: 'column',
        alignSelf: 'center',
      }}>
      {/* {!!value && Number(value) > 0 && (
        <RegularText
          text={`${Number(value) + 1}`}
          styles={{textAlign: 'center', fontSize: 12, color: '#6A6A6A'}}
        />
      )} */}

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'flex-start',
          alignContent: 'center',
          alignSelf: 'center',
        }}>
        <InputSpinner
          min={panelType ? 2 : 1}
          max={40}
          step={1}
          colorMax={'#EBEBEB'}
          colorMin={'#EBEBEB'}
          value={value}
          rounded={true}
          inputProps={{
            minWidth: 32,
            paddingHorizontal: 6,
            paddingVertical: 0,
            backgroundColor: 'white',
            height: 32,
            borderWidth: 1,
            borderColor: '#878787',
          }}
          buttonRightImage={
            <ChevronUpIcon fill={'black'} height={16} width={16} />
          }
          buttonLeftImage={
            <ChevronDownIcon fill={'black'} height={16} width={16} />
          }
          buttonTextColor={'black'}
          buttonStyle={{
            borderWidth: 1,
            borderColor: 'black',
            borderRadius: 5,
            backgroundColor: '#EBEBEB',
          }}
          height={32}
          prepend={<Spacer />}
          append={<Spacer />}
          accelerationDelay={5000}
          onChange={(value: string | number,index: number) => onChange(value, index)}
          type="int"
        />
      </View>

      {/* {!!value && Number(value) > 0 && (
        <RegularText
          text={`${Number(value) - 1}`}
          styles={{textAlign: 'center', fontSize: 12, color: '#6A6A6A'}}
        />
      )} */}
    </View>
  );
};
