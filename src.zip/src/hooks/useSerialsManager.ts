import {useEffect, useState} from 'react';
import ScanResult from '../interfaces/ScanResult';
import {filterScanned} from '../components/MultiScan/MultiScanHelpers';
import {WorkflowState} from './useWorkflow';
import PackageInfo from '../interfaces/PackageInfo';
import { Logging } from './useLogging';

export const useSerialsManager = (
  packageInfo: PackageInfo | null,
  boardNumberPerPanel: string,
  setWorkflowState : (state: WorkflowState) => void,
  logging: Logging,
) => {
  const [serialNumbers, setSerialNumbers] = useState<string[]>([]);
  const [serialNoCountToSend, setSerialNoCountToSend] = useState<number>(0);

  const [okToSend, setOkToSend] = useState<boolean>(false);
  const [allSentSerials, setAllSentSerials] = useState<string[]>([]);
  const [sentSerialNumbersForPackage, setSentSerialNumbersForPackage] = useState<string[]>([]);
  const [panelsSentForPackage, setPanelsSentForPackage] = useState<number>(0);

  const resetSerialsManagerForNewPackage = () => {
    setSerialNumbers([]);
    setSentSerialNumbersForPackage([]);
    setPanelsSentForPackage(0);
    setOkToSend(false);
    setSerialNoCountToSend(0);
  };

  const resetSerialsManager = () => {
    setSerialNumbers([]);
    setSentSerialNumbersForPackage([]);
    setPanelsSentForPackage(0);
    setAllSentSerials([]);
    setOkToSend(false);
    setSerialNoCountToSend(0);
  };

  useEffect(() => {
    if (
      boardNumberPerPanel.length &&
      !isNaN(parseInt(boardNumberPerPanel)) &&
      packageInfo
    ) {
      setSerialNoCountToSend(parseInt(boardNumberPerPanel));
    }
  }, [packageInfo, boardNumberPerPanel]);

  const appendSerialNumbers = (serials: ScanResult[]) => {
    try {
      const filteredSerials = filterScanned(
        serials,
        serialNumbers,
        sentSerialNumbersForPackage,
      );

      setSerialNumbers([...serialNumbers, ...filteredSerials]);
      setWorkflowState(WorkflowState.SerialList);
    } catch (error) {
      logging.sendErrorLog(
        `"message": "error on scan serials ${error}. New serials: ${encodeURIComponent(
          JSON.stringify(serials),
        )}, serial numbers ${serialNumbers.join(', ')}, 
        sent serial numbers  ${sentSerialNumbersForPackage.join(', ')}"`,
      );
    }
  };

  return {
    serialNumbers,
    setSerialNumbers: (serials: any[]) => {
      setSerialNumbers(serials);
      if (
          boardNumberPerPanel &&
          serials.length === Number(boardNumberPerPanel)
      ) {
        setWorkflowState(WorkflowState.SerialList);
      }
    },
    serialNoCountToSend,
    okToSendSerials: okToSend,
    setOkToSendSerials: setOkToSend,
    sentSerialNumbersForPackage,
    setSentSerialNumbersForPackage,
    panelsSentForPackage,
    setPanelsSentForPackage,
    resetSerialsManagerForNewPackage,
    resetSerialsManager,
    appendSerialNumbers,
    allSentSerials,
    setAllSentSerials,
  };
};
