import React, { Dispatch, ReducerAction } from 'react';
import {Alert} from 'react-native';
import PackageInfo from '../interfaces/PackageInfo';
import Settings from '../interfaces/Settings';

import labelReport from '../utils/labelReport';
import {IOrder} from './useWorkflow';
import {alertError} from '../components/PackageInfoDetails';
import {WorkflowAction, WorkflowReducerState, WorkflowState} from './reducers/workflowReducer';

interface SendLabelReportResult {
  sendLabelReport: (
    serialNumbers: string[],
    lineNumber: string,
    pi: PackageInfo,
    order: IOrder,
    boardType: string
  ) => void;
}

const errorAlert = (error: any) => {
  Alert.alert(
    'Serials label report',
    `Error on sending label report  ${error} `,
    [
      {
        text: 'Ok',
      },
    ],
    {
      cancelable: true,
    },
  );
};

const handlePanelsSent = (
  sent: string[],
  workflowState: WorkflowReducerState,
  dispatch: Dispatch<ReducerAction<any>>,
) => {
  const {
    sentSerialNumbersForPackage,
    allSentSerials,
    serialNumbers,
    panelsSentForPackage,
    noOfTimesScan
  } = workflowState;
  const _sentSerialNumbers: string[] = [];
  dispatch({
    type: WorkflowAction.Set,
    payload: {property: 'panelsSentForPackage', value : panelsSentForPackage + 1,}
  });
  

  sent.forEach(x => {
    if (sentSerialNumbersForPackage.indexOf(x)) {
      _sentSerialNumbers.push(x);
    }
  });

  const updatedSentSerialNumbersForPackage =
    sentSerialNumbersForPackage.concat(_sentSerialNumbers);
  dispatch({
    type: WorkflowAction.Set,
    payload: {property: 'sentSerialNumbersForPackage', value:updatedSentSerialNumbersForPackage},
  });

  const updatedAllSentSerials = [
    ...allSentSerials,
    ...sentSerialNumbersForPackage
      .concat(_sentSerialNumbers)
      .filter(serial => !allSentSerials.includes(serial)),
  ];
  dispatch({
    type: WorkflowAction.Set,
    payload: {property: 'allSentSerials' , value: updatedAllSentSerials},
  });

  const updatedSerials = serialNumbers.filter(x =>
    sentSerialNumbersForPackage.includes(x),
  );
  dispatch({
    type: WorkflowAction.Set,
    payload: {property: 'serialNumbers', value: updatedSerials},
  });
  if( panelsSentForPackage+1  ===  Number(noOfTimesScan)){
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'scanDone', value : true}
    })
  }
};

export const useSendLabelReport = (
  settings: Settings,
  jwt: string | null,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  restartScan: () => void,
  logging: {
    sendErrorLog: (error: string) => void;
    sendWarningLog: (error: string) => void;
    sendInfoLog: (error: string) => void;
  },
  workflowState: WorkflowReducerState,
  dispatch: Dispatch<ReducerAction<any>>,
): SendLabelReportResult => {
  const {panelsSentForPackage,noOfTimesScan} =
    workflowState;
  const sendLabelReport = (
    serialNumbers: string[],
    lineNumber: string,
    pi: PackageInfo,
    order: IOrder,
    boardType: string
  ) => {
    if (settings) {
      const lr = labelReport.createLabelReport(
        serialNumbers,
        lineNumber,
        pi,
        order,
        boardType
      );

      setIsLoading(true);
      fetch(
        `${settings.endpoint}${
          settings.alternativeReportEndpointEnabled
            ? '/invoke/test/processLabelReports'
            : '/invoke/processLabelReports'
        }`,
        {
          method: 'POST',
          body: JSON.stringify(lr),
          headers: {
            'Content-Type': 'application/json',
            Authorization: `${jwt}`,
          },
        },
      )
        .then(res => {
          console.log('response1', res)
          if (res.status === 200) {      
              logging.sendInfoLog(
                `"body": "${encodeURIComponent(
                  JSON.stringify(lr),
                )}", "message": "XML sent successfully"`,
              );
              Alert.alert(
                'Serials label report',
                `${serialNumbers.join(', ')} sent successfully `,
                [
                  {
                    text: 'Ok',
                    onPress: () => {
                      handlePanelsSent(serialNumbers, workflowState, dispatch);
                      panelsSentForPackage + 1 !== Number(noOfTimesScan) && restartScan();
                    },
                  },
                ],
                {
                  cancelable: true,
                  onDismiss: () => {
                    handlePanelsSent(serialNumbers, workflowState, dispatch);
                    panelsSentForPackage + 1 !== Number(noOfTimesScan) && restartScan();
                  },
                },
              );
            return;
          }
          else if (res.status === 400){
            Alert.alert(
              'Serials label report',
              `${res._bodyText} got failed. Please rescan!`,
              [
                {
                  text: 'Ok',
                  onPress: () => {
                      dispatch({
                        type: WorkflowAction.Set,
                        payload: {property: 'serialNumbers', value: []},
                      });
        
                      dispatch({
                        type: WorkflowAction.Set,
                        payload: {property: 'scanDone', value: false},
                      });
                    restartScan();
                  },
                },
              ],
            )
          } else {
            logging.sendErrorLog(
              `"message": "error sending XML. StatusCode ${res.status}"`,
            );
            throw Error(
              `Server error. StatusCode ${res.status}. Please contact support if problem remains.`,
            );
          }
        })
        .catch(err => {
          var errMessage = err;
          console.log('err', err.status);
          if (err instanceof Error) {
            //TODO: handle possible Timeout, Network request failed
            errMessage = err.message;
          }
          logging.sendErrorLog(`"message": "${errMessage}"`);
          errorAlert(errMessage);
        })

        .finally(() => setIsLoading(false));
    } else {
      logging.sendErrorLog(
        `"message": "error sending reports. wrong settings"`,
      );
      errorAlert('error sending reports. wrong settings');
    }
  };

  return {sendLabelReport};
};
