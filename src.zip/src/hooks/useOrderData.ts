import React, {useState} from 'react';
import {Alert} from 'react-native';

import {IOrder} from './useWorkflow';

interface UseOrderDataResult {
  fetchOrder: () => Promise<void>;
}

const query = (orderId: string) => {
  const params = {orderId};
  return `?orderId=${encodeURIComponent(params.orderId)}`;
};

const fetchOrder = async (orderNumber: string, endpoint: string, jwt: string) =>
  new Promise<IOrder>((resolve, reject) => {
    const url = `${endpoint}/invoke/I200118GetOrderData.imp.c1.services:GetOrderData`;

    let headers = {
      Accept: 'application/json',
      Authorization: `${jwt}`,
    };
    fetch(`${url}${query(orderNumber)}`, {
      method: 'GET',
      headers,
    })
      .then(res => {
        if (!res.ok) {
          reject(`Status code: ${res.status}`);
        } else {
          resolve(res.json());
        }
      })
      .catch(err => {
        if (err instanceof Error) {
          //TODO: handle possible Timeout, Network request failed
          reject(err.message);
        } else {
          reject(err);
        }
      });
  });

const showError = (error: any) => {
  Alert.alert(
    'Error',
    `Failed to get order: ${error}`,
    [
      {
        text: 'Ok',
      },
    ],
    {
      cancelable: true,
    },
  );
};

export const useOrderData = (
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  setOrder: React.Dispatch<React.SetStateAction<IOrder | null>>,
  orderNumber: string,
  endpoint: any,
  jwt: any,
  logging: {
    sendErrorLog: (error: string) => void;
    sendWarningLog: (error: string) => void;
    sendInfoLog: (error: string) => void;
  },
): UseOrderDataResult => {
  const fetchOrderData = () => {
    setIsLoading(true);
    return fetchOrder(orderNumber, endpoint, jwt)
      .then(res => {
        if (res?.errorMessage) {
          logging.sendWarningLog(
            `"query": "${encodeURIComponent(
              query(orderNumber),
            )}", "message": "${res.errorMessage}"`,
          );
          showError(res.errorMessage);
        } else {
          setOrder(res);
        }
      })
      .catch(err => {
        const errMessage= `Failed to get order data: ${err}`;
        showError(errMessage);
        logging.sendErrorLog(`"message": "${errMessage}"`);
      })
      .finally(() => setIsLoading(false));
  };

  return {
    fetchOrder: fetchOrderData,
  };
};
