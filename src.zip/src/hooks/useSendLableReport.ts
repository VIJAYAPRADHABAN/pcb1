import React, {useEffect, useState} from 'react';
import PackageInfo from '../interfaces/PackageInfo';
import Settings from '../interfaces/Settings';

import labelReport from '../utils/labelReport';

interface SendLabelReportResult {
  sendLabelReport: (
    serialNumbers: string[],
    lineNumber: string,
    pi: PackageInfo,
  ) => void;
  error: string;
}

export const useSendLabelReport = (
  settings: Settings,
  jwt: string | null,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  restartScan: () => void
): SendLabelReportResult => {
  const [error, setError] = useState<any>('');
  console.log('useSendLabelReport');

  const sendLabelReport = (
    serialNumbers: string[],
    lineNumber: string,
    pi: PackageInfo,
  ) => {
    if (settings) {
      const lr = labelReport.createLabelReport(
        serialNumbers,
        lineNumber,
        pi,
        settings,
      );
      console.log('sendLabelReport', settings?.endpoint, jwt);
      setIsLoading(true);
      fetch(
        `${settings.endpoint}/invoke/I210701FolderUpload.imp.c1.services:FolderUpload`,
        {
          method: 'POST',
          body: JSON.stringify(lr),
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${jwt}`,
          },
        },
      )
        .then(res => {
          console.log('FolderUpload res', res);
          if (res.status == 200) {
            restartScan()
          }
        })
        .catch(err => console.error('err', err))
        .finally(() => setIsLoading(false));
    } else {
      console.log('sendLabelReport error');

      setError('wrong settings');
    }
  };

  return {sendLabelReport, error};
};
