export default interface ProdOrderNonSerializedMaterialValidateInput {
  productNumber: string;
  productionOrderNo: string;
  rState: string;
}
