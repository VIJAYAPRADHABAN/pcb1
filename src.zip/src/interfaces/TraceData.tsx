import LabelData from './LabelData';

export default interface TraceData {
  LabelData: LabelData[];
}
