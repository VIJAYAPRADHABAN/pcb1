import TraceData from '../interfaces/TraceData';
import LabelData from '../interfaces/LabelData';
import LabelReport from '../interfaces/LabelReport';
import SupplierData from '../interfaces/SupplierData';
import PackageInfo from '../interfaces/PackageInfo';
import {IOrder} from '../hooks/useWorkflow';

const createLabelReport = (
  serials: string[],
  line: string,
  pi: PackageInfo,
  order: IOrder,
  boardType:string
): LabelReport => {
  const SupplierData: SupplierData = {
    ProductNo: pi.productNo,
    RState: pi.rState,
    SupplierCode: pi.factoryCode,
    SupplierPartNo: pi.supplierPartNo,
    SupplierRev: pi.supplierVersion,
    MadeIn: pi.countryCode,
    ManufacturedDate: pi.manufactureDate,
    BatchNo: pi.batchNumber,
    MSL: pi.msl,
  };

  const ld: LabelData[] = [];
  serials.forEach((Serialnumber, index) => {
    ld.push({ArrayID: `${index + 1}`, Serialnumber});
  });

  const td: TraceData = {LabelData: ld};

  const lineNumber = `${line}`.padStart(2, '0');
  const panel = boardType;

  const lr: LabelReport = {
    Program: `${order.productNumber}_${order.productRevision}`,
    TimeDone: new Date().toISOString(),
    Equipment: `LINE${lineNumber}`,
    Panel: panel,
    SupplierData,
    TraceData: td,
  };

  return lr;
};

export default {
  createLabelReport,
};
