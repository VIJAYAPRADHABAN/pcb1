import {Platform} from 'react-native';

export const azureConfig = {
  clientId: '<YOUR_AZURE_CLIENT_ID>',
  redirectUrl: Platform.select({
    ios: '<YOUR_IOS_REDIRECT_URL>',
    android: '<YOUR_ANDROID_REDIRECT_URL>',
  }),
  scopes: ['openid', 'profile', 'email', 'offline_access'],
  serviceConfiguration: {
    authorizationEndpoint: 'https://login.microsoftonline.com/<YOUR_TENANT_ID>/oauth2/v2.0/authorize',
    tokenEndpoint: 'https://login.microsoftonline.com/<YOUR_TENANT_ID>/oauth2/v2.0/token',
  },
};