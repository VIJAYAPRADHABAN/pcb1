import React, {useEffect, useReducer} from 'react';
import {
  PanResponder,
  SafeAreaView,
  StyleSheet,
  View,
  AppState,
  AppStateStatus,
} from 'react-native';


import Toolbar from './Toolbar';
import Footer from './Footer';
import OrderNumber from './OrderNumber';
import ProdOrderValidate from './ProdOrderValidate';
import ScanHook from './ScanHook';
import AmountOfBoards from './AmountOfBoards';
import SerialList from './SerialList';
import Login, {hasSuperUserPermissions} from './Login';

import ChangeSettings from './ChangeSettings';
import {useWorkflow} from '../hooks/useWorkflow';
import LoadingOverlay from './LoadingOverlay';
import {useOrderData} from '../hooks/useOrderData';
import {useSendLabelReport} from '../hooks/useSendLabelReport';
import Settings from '../interfaces/Settings';
import {Symbology} from 'scandit-react-native-datacapture-barcode';
import PackageInfo from '../interfaces/PackageInfo';
import {alertError, infoAlert, PackageInfoDetails} from './PackageInfoDetails';
import {useProdOrderNonSerializedMaterialValidate} from '../hooks/useProdOrderNonSerializedMaterialValidate';
import {useLogging} from '../hooks/useLogging';
import {useFooterButtons} from '../hooks/useFooterButttons';
import {
  WorkflowAction,
  workflowReducer,
  workflowReducerInitialState,
  WorkflowState,
} from '../hooks/reducers/workflowReducer';
import {isEqual} from 'lodash';
import {useAuth} from '../hooks/useAuth';

const styles = StyleSheet.create({
  workFlowContainer: {
    flex: 1,
    justifyContent: 'space-between',
    backgroundColor: '#EBEBEB',
  },
});
export interface WorkflowProps {
  settings: Settings;
  saveSettings: (settings: Settings) => void;
}
const WorkFlow: React.FC<WorkflowProps> = ({settings, saveSettings}) => {
  const [state, dispatch] = useReducer(
    workflowReducer,
    workflowReducerInitialState,
  );

  useEffect(() => {
    // console.log(state);
  }, [state]);

  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const {user, jwt, logout, login, refreshToken, isTokenRefreshNeeded} =
    useAuth(settings, setIsLoading, state, dispatch);

  const logging = useLogging(settings.endpoint, user);

  const {
    setOrder,
    setPackageInfo,
    resetWorkflow,
    resetWorkflowForNextPackage,
    userLogout,
    resetSerialsData,
    setSerialNumbers,
    appendSerialNumbers,
    saveStateToStorage,
  } = useWorkflow(settings, jwt, user, logging, state, dispatch);

  const checkAndRefreshToken = () => {
    if (isTokenRefreshNeeded()) {
      refreshToken();
    }
  };

  const _panResponder = PanResponder.create({
    onStartShouldSetPanResponderCapture: () => {
      checkAndRefreshToken();
      return false;
    },
  });

  const checkOnBackFromBackground = (nextAppState: AppStateStatus) => {
    if (nextAppState == 'active') {
      checkAndRefreshToken();
    }
  };

  useEffect(() => {
    AppState.addEventListener('change', checkOnBackFromBackground);
    return () => {
      AppState.removeEventListener('change', checkOnBackFromBackground);
    };
  }, [jwt]);

  const {fetchOrder} = useOrderData(
    setIsLoading,
    setOrder,
    state.orderNumber,
    settings.endpoint,
    jwt,
    logging,
  );

  const {checkPackageInfoAndValidate} =
    useProdOrderNonSerializedMaterialValidate(
      state.parsedPackageInfo,
      state.orderNumber,
      settings,
      jwt,
      setIsLoading,
      setPackageInfo,
      logging,
    );

  const resetToOrderScan = () => {
    resetWorkflow();
    resetSerialsData();

    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'orderNumber', value: ''},
    });
    
    dispatch({
      type: WorkflowAction.UpdateFlow,
      payload: WorkflowState.OrderNumber,
    });
  };

  const setNextPackageWorkflowState = () => {
    resetWorkflowForNextPackage();
    resetSerialsData(true);
  };

  const resetAppState = () => {
    userLogout();
    resetSerialsData();
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'serialNumbers', value: []},
    });
  };

  const restartScan = () => {
    dispatch({
      type: WorkflowAction.UpdateFlow,
      payload: WorkflowState.ScanSerials,
    });
  };

  const {sendLabelReport} = useSendLabelReport(
    settings,
    jwt,
    setIsLoading,
    restartScan,
    logging,
    state,
    dispatch,
  );

  useEffect(() => {
    if (!jwt) {
      resetAppState();
    }
  }, [jwt]);

  useEffect(() => {
    if (!!user && !hasSuperUserPermissions(user) && !settings.endpoint) {
      alertError(
        'WARNING',
        'API endpoint is not set. Please contact an administrator.',
      );
    }
  }, []);

  const handlePackageScanError = () => {
    dispatch({
      type: WorkflowAction.UpdateFlow,
      payload: WorkflowState.OrderNumber,
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'scanDone', value: false},
    });
  };

  const askToSaveState = () => {
    const {order, allSentSerials} = state;
    infoAlert(
      'Logged out',
      'Previous progress might be lost. Would you like to save it?',
      async () => {
        await saveStateToStorage(state);
        resetAppState();
        logout();
      },
      async () => {
        await saveStateToStorage(null);
        resetAppState();
        logout();
        logging.sendInfoLog(
          `"message": 'User logout without finishing order ${order?.orderId}. Total of ${allSentSerials.length} serials sent.'`,
        );
      },
      [],
      'Save',
      'Do not save',
    );
  };

  const userLogoutClicked = async () => {
    const {allSentSerials} = state;

    const initialStateForComparison = {
      ...state,
      previous: workflowReducerInitialState.previous,
      current: workflowReducerInitialState.current,
    };

    if (
      user &&
      !isEqual(initialStateForComparison, workflowReducerInitialState) &&
      allSentSerials.length !== Number(state.order?.quantity)
    ) {
      infoAlert(
        'Warning',
        'Number of serials scanned does not match with order quantity!',
        async () => {
          askToSaveState();
        },
        () => {},
      );
    } else {
      resetAppState();
      logout();
    }
  };

  const scanPackageClicked = () => {
    jwt && fetchOrder();
  };

  const {getFooterButtons} = useFooterButtons({
    scanPackageClicked,
    setPackageInfo,
    setSerialNumbers,
    checkPackageInfoAndValidate,
    setOrder,
    state,
    dispatch,
    setNextPackageWorkflowState,
    userLogoutClicked,
    resetToOrderScan,
    sendLabelReport,
  });

  return (
    <SafeAreaView style={{flex: 1}} {..._panResponder.panHandlers}>
      <View style={styles.workFlowContainer}>
        {isLoading && <LoadingOverlay />}

        {state.current !== WorkflowState.Settings && (
          <Toolbar
            logout={userLogoutClicked}
            user={user}
            setShowSettings={() =>
              dispatch({
                type: WorkflowAction.UpdateFlow,
                payload: WorkflowState.Settings,
              })
            }
          />
        )}

        {state.current === WorkflowState.Unauthenticated && (
          <Login login={login} />
        )}

        {state.current === WorkflowState.Settings && (
          <ChangeSettings
            settings={settings}
            user={user}
            saveSettings={saveSettings}
            previousWorkflowState={state.previous}
            setWorkflowState={state =>
              dispatch({type: WorkflowAction.UpdateFlow, payload: state})
            }
          />
        )}

        {state.current === WorkflowState.OrderNumber && (
          <OrderNumber workflowState={state} dispatch={dispatch} />
        )}

        {state.current === WorkflowState.ScanProductNumber && (
          <>
            {state.parsedPackageInfo ? (
              <PackageInfoDetails workflowState={state} dispatch={dispatch} />
            ) : (
              <ProdOrderValidate
                setParsedPackageInfo={(value: PackageInfo | null) =>
                  dispatch({
                    type: WorkflowAction.Set,
                    payload: {property: 'parsedPackageInfo', value: value},
                  })
                }
                scanDone={state.scanDone}
                logging={logging}
                handlePackageScanError={handlePackageScanError}
              />
            )}
          </>
        )}

        {state.current === WorkflowState.EnterBoardNumberPerPanel && (
          <AmountOfBoards dispatch={dispatch} workflowState={state} />
        )}

        {state.current === WorkflowState.ScanSerials && (
          <ScanHook
            scannedSerials={state.serialNumbers}
            allSentSerials={state.allSentSerials}
            setCode={appendSerialNumbers}
            isMultiScan={true}
            amountToScan={state.boardNumberPerPanel}
            continueOnAmountReached={true}
            enableSymbologies={[Symbology.DataMatrix]}
            scanDone={state.scanDone}
          />
        )}

        {state.current === WorkflowState.SerialList &&
          !!state.order &&
          !!state.packageInfo && (
            <SerialList
              workflowState={state}
              dispatch={dispatch}
              logging={logging}
              resetWorkflow={resetToOrderScan}
            />
          )}

        {state.current !== WorkflowState.Settings &&
          state.current !== WorkflowState.Unauthenticated && (
            <Footer footerButtons={getFooterButtons(state.current)} />
          )}
      </View>
    </SafeAreaView>
  );
};

export default WorkFlow;