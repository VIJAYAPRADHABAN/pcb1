import {Component} from 'react';
import {AppState, BackHandler, View, Alert} from 'react-native';
import {
  BarcodeTracking,
  BarcodeTrackingBasicOverlay,
  BarcodeTrackingListener,
} from 'scandit-react-native-datacapture-barcode';
import {
  DataCaptureView,
  FrameSourceState,
} from 'scandit-react-native-datacapture-core';

import {requestCameraPermissionsIfNeeded} from '../../services/cameraPermissionHandler';
import * as lodashJs from 'lodash';
import React from 'react';
import {filterScanned} from './MultiScanHelpers';
import ScanResult from '../../interfaces/ScanResult';
import {BoldText, RegularText} from '../Text/RegularText';

interface IProps {
  onClose?: any;
  onSuccess?: any;
  barcodeTracking: BarcodeTracking;
  addBarcodeTrackingMode(): void;
  removeAllModes(): void;
  amountToScan: string | undefined;
  continueOnAmountReached: boolean;
  allSentSerials?: string[];
  scannedSerials?: any[];
  scanDone: boolean;
}

interface IState {
  barCodes: any;
  pdf417ScannedAmount: number;
  code128ScannedAmount: number;
}

export default class MultiScan extends Component<IProps, IState> {
  viewRef: any;
  results: any;
  barcodeTracking: any;
  barcodeTrackingListener: BarcodeTrackingListener;
  constructor(props: IProps) {
    super(props);
    this.viewRef = React.createRef();
    this.props.addBarcodeTrackingMode();
    // Register a listener to get informed whenever a new barcode is tracked.
    this.barcodeTrackingListener = {
      didUpdateSession: (_, session) => {
        let newBarCodes: any = [];
        const barCodesInState = this.state.barCodes;

        Object.values(session.trackedBarcodes).forEach(
          (trackedBarcode: any) => {
            if (!trackedBarcode) {
              return;
            }

            const code = {
              data: trackedBarcode.barcode.data.trim(),
              type: trackedBarcode.barcode.symbology.trim(),
            };

            let codeNotInSentSerials = true;
            if (this.props.allSentSerials) {
              codeNotInSentSerials =
                filterScanned(
                  [code],
                  this.state.barCodes,
                  this.props.allSentSerials ? this.props.allSentSerials : [],
                ).length > 0;
            }

            let codeNotInScannedSerials = true;
            if (this.props.scannedSerials) {
              codeNotInScannedSerials =
                filterScanned(
                  [code],
                  this.state.barCodes,
                  this.props.scannedSerials ? this.props.scannedSerials : [],
                ).length > 0;
            }

            codeNotInSentSerials &&
              codeNotInScannedSerials &&
              newBarCodes.push(code);
          },
        );

        newBarCodes.length > 0 &&
          this.handleNewBarCodes(newBarCodes, barCodesInState);
      },
    };
    this.props.barcodeTracking.addListener(this.barcodeTrackingListener);

    this.results = {};
    this.onClose = this.onClose.bind(this);
    this.completeScan = this.completeScan.bind(this);

    this.state = {
      barCodes:
        this.props.scannedSerials && this.props.scannedSerials.length > 0
          ? this.props.scannedSerials.map((serial: string) => ({
              data: serial,
              type: 'prev-scanned',
            }))
          : [],
      pdf417ScannedAmount: 0,
      code128ScannedAmount: 0,
    };
  }

  componentDidUpdate(prevProps:IProps) {
    if (prevProps.scanDone !== this.props.scanDone && this.props.scanDone) {
      this.props.onSuccess(this.state.barCodes);
      this.onClose();
    }
  }

  handleNewBarCodes(newBarCodes: any[], barCodesInState: any[]) {
    const updatedBarCodes = lodashJs.unionBy(
      barCodesInState,
      newBarCodes,
      'data',
    );

    const pdfsScanned = updatedBarCodes.filter(
      (code: ScanResult) => code.type === 'pdf417',
    );

    const code128sScanned = updatedBarCodes.filter(
      (code: ScanResult) => code.type === 'code128',
    );

    this.setState({
      barCodes: updatedBarCodes,
      pdf417ScannedAmount: pdfsScanned.length,
      code128ScannedAmount: code128sScanned.length,
    });

    if (
      updatedBarCodes.length === Number(this.props.amountToScan) &&
      this.props.continueOnAmountReached
    ) {
      this.onClose();
      this.props.onSuccess(this.state.barCodes);
    }

    if (updatedBarCodes.length > Number(this.props.amountToScan)) {
      const slicedBarCodes = this.state.barCodes.slice(
        0,
        Number(this.props.amountToScan),
      );
      const pdfsScanned = slicedBarCodes.filter(
        (code: ScanResult) => code.type === 'pdf417',
      );

      const code128sScanned = slicedBarCodes.filter(
        (code: ScanResult) => code.type === 'code128',
      );

      this.setState({
        ...this.state,
        barCodes: slicedBarCodes,
        pdf417ScannedAmount: pdfsScanned.length,
        code128ScannedAmount: code128sScanned.length,
      });

      if (this.props.continueOnAmountReached) {
        this.onClose();
        this.props.onSuccess(this.state.barCodes);
      }
    }
  }

  componentDidMount() {
    AppState.addEventListener('change', this.handleAppStateChange);
    this.setupScanning();
    this.startCapture();
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this.handleAppStateChange);
    this.props.barcodeTracking.removeListener(this.barcodeTrackingListener);
  }

  handleAppStateChange = async (nextAppState: string) => {
    nextAppState.match(/inactive|background/)
      ? this.stopCapture()
      : this.startCapture();
  };

  onClose = () => {
    this.stopCapture();
    this.props.onClose();
  };

  startCapture() {
    this.startCamera();
    this.props.barcodeTracking.isEnabled = true;
    this.props.addBarcodeTrackingMode();
  }

  stopCapture() {
    this.props.barcodeTracking.isEnabled = false;
    this.stopCamera();
    this.props.barcodeTracking.removeListener(this.barcodeTrackingListener);
    this.props.removeAllModes();
  }

  stopCamera() {
    this.props.barcodeTracking.context?.frameSource?.switchToDesiredState(
      FrameSourceState.Off,
    );
  }

  startCamera() {
    requestCameraPermissionsIfNeeded()
      .then(() => {
        this.props.barcodeTracking.context?.frameSource?.switchToDesiredState(
          FrameSourceState.On,
        );
      })
      .catch(err => {
        console.error(`Error on starting camera ${err}`);
        Alert.alert(
          'Fatal error',
          `${err}`,
          [
            {
              text: 'Ok',
              onPress: () => BackHandler.exitApp(),
            },
          ],
          {
            cancelable: false,
          },
        );
      });
  }

  setupScanning() {
    // Add a barcode tracking overlay to the data capture view to render the location of captured barcodes on top of
    // the video preview. This is optional, but recommended for better visual feedback.
    BarcodeTrackingBasicOverlay.withBarcodeTrackingForView(
      this.props.barcodeTracking,
      this.viewRef.current,
    );
  }

  completeScan(): void {
    this.stopCapture();
    this.props.onSuccess(this.state.barCodes);
    BarcodeTrackingBasicOverlay.withBarcodeTrackingForView(
        this.props.barcodeTracking,
        null,
    );
  }

  render() {
    return (
      <>
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
          }}>
          <DataCaptureView
            style={{
              flex: 1,
              flexDirection: 'column',
            }}
            context={this.props.barcodeTracking.context!}
            ref={this.viewRef}
          />

          <View
            style={{
              position: 'absolute',
              bottom: '90%',
              marginLeft: 16,
              paddingHorizontal: 12,
              paddingVertical: 8,
              height: this.state.pdf417ScannedAmount > 0 ? 55 : 37,
              minWidth: 117,
              backgroundColor: 'black',
            }}>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <RegularText styles={{color: '#8B8B8B'}} text={'Scanned barcodes'} />

              <BoldText
                styles={{color: this.state.barCodes.length == this.props.amountToScan ? 'green' : 'white', marginLeft: 8}}
                text={
                  this.state.pdf417ScannedAmount > 0
                    ? ` ${this.state.code128ScannedAmount} / ${
                        Number(this.props.amountToScan) -
                        this.state.pdf417ScannedAmount
                      }`
                    : ` ${this.state.barCodes.length} / ${this.props.amountToScan}`
                }
              />
            </View>

            {this.state.pdf417ScannedAmount > 0 && (
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <RegularText styles={{color: '#8B8B8B'}} text={'2D codes'} />
                <BoldText
                  styles={{color: this.state.pdf417ScannedAmount > 0 ? 'green' : 'white', marginLeft: 8}}
                  text={`${this.state.pdf417ScannedAmount}`}
                />
              </View>
            )}
          </View>
        </View>
      </>
    );
  }
}
