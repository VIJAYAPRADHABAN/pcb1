import React, {useState} from 'react';
import {View, StyleSheet, Platform, Alert} from 'react-native';
import {authorize} from 'react-native-app-auth';
import EdsButton from './Button/EdsButton';
import User from '../interfaces/User';
import {BoldText} from './Text/RegularText';
import {EricssonLogo} from '../assets/logo/EricssonLogo';
import {azureConfig} from '../config/authConfig';

const iosStyles = StyleSheet.create({
  textInput: {
    marginTop: 32,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: 'center',
    backgroundColor: '#EBEBEB',
  },
  input: {
    height: 40,
    marginVertical: 12,
    borderWidth: 1,
    paddingHorizontal: 5,
    backgroundColor: 'white',
    borderColor: '#878787',
  },
  saveButtonContainer: {
    marginTop: 12,
  },
  logo: {
    height: 31,
  },
});

const androidStyles = StyleSheet.create({
  textInput: {
    marginTop: 17,
    marginBottom: 32,
    fontSize: 18,
    lineHeight: 27,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    backgroundColor: '#EBEBEB',
  },
  input: {
    fontFamily: 'EricssonHilda-Regular',
    fontSize: 14,
    lineHeight: 21,
    color: 'black',
    borderColor: '#878787',
    height: 40,
    marginVertical: 12,
    borderWidth: 1,
    minWidth: 40,
    textAlign: 'left',
    backgroundColor: 'white',
  },
  saveButtonContainer: {
    marginTop: 12,
  },
});

const superUsers: string[] = [
  'idm-esst-ssml-superuser',
  'idm-esst-ssml-test-superuser',
  'idm-enc-ssml-superuser',
  'idm-efa-ssml-superuser',
  'idm-edb-ssml-superuser',
];

export const hasSuperUserPermissions = (user: User): boolean => {
  return user.roles.some((role: string) => superUsers.includes(role));
};

export interface LoginProps {
  login: (idToken: string) => void;
}

const Login: React.FC<LoginProps> = ({login}) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const styles = Platform.OS === 'ios' ? iosStyles : androidStyles;

  const _login = async () => {
    try {
      setIsLoading(true);
      const result = await authorize(azureConfig);
      login(result.idToken);
    } catch (error: any) {
      Alert.alert('Login Failed', error.message || 'Unable to authenticate');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View>
        <EricssonLogo height={56} width={41.46} fill="#000000" />
      </View>
      <BoldText styles={styles.textInput} text={'PCBTrace Manual Scanner'} />
      <View style={styles.saveButtonContainer}>
        <EdsButton
          onPress={_login}
          title="Login with Microsoft"
          disabled={isLoading}
          color="#1174E6"
          width="100%"
          buttonType="primary"
        />
      </View>
    </View>
  );
};

export default Login;
