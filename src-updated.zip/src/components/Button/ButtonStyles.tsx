import {StyleSheet, TextStyle, ViewStyle} from 'react-native';
export interface ButtonStyles {
  primary: TextStyle;
  warning: TextStyle;
  secondary: TextStyle;
  disabled: TextStyle;
  button: ViewStyle;
  buttonTxtStyle: TextStyle;
}
const styles = StyleSheet.create<ButtonStyles>({
  primary: {
    backgroundColor: '#0069C2',
    borderColor: '#0069C2',
  },
  warning: {
    backgroundColor: '#BB0B02',
    borderColor: '#BB0B02',
  },
  secondary: {
    backgroundColor: 'transparent',
    borderColor: '#DCDCDC',
    color: '#ffffff',
    borderWidth: 1,
  },
  disabled: {
    opacity: 0.5,
  },
  button: {
    borderRadius: 3,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 5,
    paddingLeft: 12,
    paddingRight: 12,
    paddingBottom: 5,
    minWidth: 60,
    alignSelf: 'flex-start',
  },
  buttonTxtStyle: {
    lineHeight: 21,
    fontWeight: '600',
  },
});

export default styles;
