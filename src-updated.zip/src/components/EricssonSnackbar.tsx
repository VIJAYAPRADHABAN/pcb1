import React from 'react';
// @ts-ignore
import SnackBar from 'rn-snackbar-component';

export const EricssonSnackbar = ({
  visible,
  text,
}: {
  visible: boolean;
  text: string;
}) => {
  return (
    <SnackBar
      visible={visible}
      message={text}
      position="top"
      containerStyle={{
        width: '80%',
        alignSelf: 'center',
        backgroundColor: '#329864',
      }}
      messageStyle={{
        marginLeft: -16,
        color: 'white',
        textAlign: 'center',
        width: '100%',
        fontFamily: 'EricssonHilda-Regular',
      }}
      autoHidingTime={5000}
      native={false}
    />
  );
};
