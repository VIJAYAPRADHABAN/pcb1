import React, {Component} from 'react';
import {
  AppState,
  BackHandler,
  View,
  StyleSheet,
  TouchableWithoutFeedback,
  Alert,
} from 'react-native';
import {
  BarcodeCapture,
  BarcodeCaptureListener,
  BarcodeCaptureOverlay,
} from 'scandit-react-native-datacapture-barcode';
import {
  DataCaptureView,
  FrameSourceState,
  LaserlineViewfinder,
  MarginsWithUnit,
  NumberWithUnit,
  MeasureUnit,
} from 'scandit-react-native-datacapture-core';

import {requestCameraPermissionsIfNeeded} from '../../services/cameraPermissionHandler';
import {RegularText} from '../Text/RegularText';
interface IProps {
  onClose?: any;
  onSuccess?: any;
  addBarcodeCaptureMode(): void;
  removeAllModes(): void;
  barcodeCapture: BarcodeCapture;
  title?: string;
  scanDone: boolean;
}
interface IState {
  barCode?: any;
}
export default class SingleScan extends Component<IProps, IState> {
  viewRef: any;
  barcodeCaptureMode: any;
  camera: any;
  barcodeCaptureListener: BarcodeCaptureListener;
  overlay: BarcodeCaptureOverlay | undefined;
  state: IState;
  constructor(props: IProps) {
    super(props);
    this.viewRef = React.createRef();

    this.state = {
      barCode: '',
    };

    this.props.addBarcodeCaptureMode();
    this.barcodeCaptureListener = {
      didScan: (_, session) => {
        const barcode = session.newlyRecognizedBarcodes[0];
        this.setState({barCode: barcode.data});
        this.props.barcodeCapture.isEnabled = false;
      },
    };

    this.props.barcodeCapture.addListener(this.barcodeCaptureListener);
  }

  componentDidUpdate(prevProps: IProps) {
    if (prevProps.scanDone !== this.props.scanDone && this.props.scanDone) {
      this.props.onSuccess(this.state.barCode);
    }
  }

  componentDidMount() {
    AppState.addEventListener('change', this.handleAppStateChange);
    this.setupScanning();
    this.startCapture();
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this.handleAppStateChange);
    this.props.barcodeCapture.removeListener(this.barcodeCaptureListener);
    this.setState = (state, callback) => {
      return;
    };
    this.stopCapture();
  }

  handleAppStateChange = async (nextAppState: any) => {
    if (nextAppState.match(/inactive|background/)) {
      this.stopCapture();
    } else {
      this.startCapture();
    }
  };

  startCapture() {
    this.startCamera();
    this.props.barcodeCapture.isEnabled = true;
  }

  stopCapture() {
    this.props.barcodeCapture.isEnabled = false;
    this.stopCamera();
    this.props.removeAllModes();
  }

  stopCamera() {
    this.props.barcodeCapture.context?.frameSource?.switchToDesiredState(
      FrameSourceState.Standby,
    );
  }

  startCamera() {
    // Switch camera on to start streaming frames and enable the barcode capture mode.
    // The camera is started asynchronously and will take some time to completely turn on.
    requestCameraPermissionsIfNeeded()
      .then(() =>
        this.props.barcodeCapture.context?.frameSource?.switchToDesiredState(
          FrameSourceState.On,
        ),
      )
      .catch(() => BackHandler.exitApp());
  }

  setupScanning() {
    this.viewRef.current.scanAreaMargins = new MarginsWithUnit(
      new NumberWithUnit(0.1, MeasureUnit.Fraction), // padding left
      new NumberWithUnit(0.1, MeasureUnit.Fraction), // padding top
      new NumberWithUnit(0.4, MeasureUnit.Fraction), // padding right
      new NumberWithUnit(0.4, MeasureUnit.Fraction), // padding bottom
    );
    this.overlay = BarcodeCaptureOverlay.withBarcodeCaptureForView(
      this.props.barcodeCapture,
      this.viewRef.current,
    );
    this.overlay.viewfinder = new LaserlineViewfinder();
    this.overlay.shouldShowScanAreaGuides = false;
  }

  scanIt = () => {
    this.props.barcodeCapture.isEnabled = true;
  };

  render() {
    return (
      <View style={styles.container}>
        <View style={{flex: 50}}>
          <RegularText
            styles={{textAlign: 'center', backgroundColor: '#EBEBEB'}}
            text={'* Click to rescan a value'}
          />
          <TouchableWithoutFeedback
            style={{width: '100%', height: '100%'}}
            onPress={() => {
              this.scanIt();
            }}>
            <DataCaptureView
              style={{width: '100%', height: '80%'}}
              context={this.props.barcodeCapture.context!}
              ref={this.viewRef}
            />
          </TouchableWithoutFeedback>
        </View>

        {this.props.title ? (
          <View>
            <RegularText text={this.props.title} />
          </View>
        ) : null}
        <View style={styles.barcodeContainer}>
          <RegularText styles={styles.item} text={this.state.barCode} />
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  barcodeContainer: {
    flex: 40,
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  item: {
    paddingTop: '5%',
    fontSize: 30,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  title: {
    width: '100%',
    paddingVertical: 5,
    paddingHorizontal: 10,
    fontSize: 20,
    textAlign: 'center',
  },
  tapText: {
    flex: 1,
    fontSize: 20,
    color: 'white',
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});
