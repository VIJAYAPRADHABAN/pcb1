const identifiers = new Map<string, string>([
  ['P', 'productNo'],
  ['21P', 'rState'],
  ['18V', 'factoryCode'],
  ['1P', 'supplierPartNo'],
  ['2P', 'supplierVersion'],
  ['Q', 'quantity'],
  ['11D', 'manufactureDate'],
  ['12D', 'manufactureDate'],
  ['1T', 'batchNumber'],
  ['13E', 'msl'],
  ['4L', 'countryCode'],
]);

import PackageInfo from "../../interfaces/PackageInfo"

export const parsePDF417Order = (pdf417string: string): PackageInfo => {
  const separated = pdf417string.split(':');
  const mapIterator = identifiers.keys();

  return separated.reduce(accumulator => {
    const key = mapIterator.next().value;
    const match = separated.find((value: string) => value.startsWith(key));

    if (!match) {
      return accumulator;
    }

    const value = match.slice(key.length);
    const name = identifiers.get(key);
    return {...accumulator, [`${name}`]: value};
  }, {} as PackageInfo);
};

export const parsePDF417OrderWoColons = (pdf417string: string): PackageInfo|null => {
  var regex = "^.*?P(.*)21P(.*)Q(.*)18V(.*)1P(.*)2P(.*)(?:1[1|2]{1}D(.*))1T(.*)13E(.*)4L(.*)$"
  const match = pdf417string.match(regex);

  if (match != null && match.length){
    return {
    productNo: match[1],
    rState: match[2],
    quantity: match[3],
    factoryCode: match[4],
    supplierPartNo: match[5],
    supplierVersion: match[6],
    manufactureDate: match[7],
    batchNumber: match[8],
    msl: match[9],
    countryCode: match[10],
    } as PackageInfo;
  } else return null;

};
