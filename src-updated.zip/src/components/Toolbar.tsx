import React from 'react';
import {Image, View, StyleSheet, TouchableOpacity} from 'react-native';
import User from '../interfaces/User';
import {hasSuperUserPermissions} from './Login';
import {RegularText} from './Text/RegularText';

const styles = StyleSheet.create({
  logo: {
    width: 12,
    height: 16,
    margin: 16,
  },
  toolbar: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    height: 48,
    backgroundColor: '#0C0C0C',
  },
  spacer: {
    flex: 1,
    justifyContent: 'space-between',
  },
  title: {
    color: 'white',
    fontSize: 14,
    lineHeight: 21,
  },
  icon: {
    width: 16,
    height: 16,
    margin: 16,
  },
});

interface ToolbarProps {
  setShowSettings: any;
  logout: any;
  user: User | null;
}

const Toolbar: React.FC<ToolbarProps> = ({setShowSettings, logout, user}) => {
  return (
    <View style={styles.toolbar}>
      <Image
        source={require('../assets/logo/ericsson_logo.png')}
        style={styles.logo}
      />
      <RegularText styles={styles.title} text={'PCBTrace Manual Scanner'} />

      {(user && hasSuperUserPermissions(user)) && (
        <TouchableOpacity onPress={() => setShowSettings(true)}>
          <Image
            source={require('../assets/logo/settings.png')}
            style={styles.icon}
          />
        </TouchableOpacity>
      )}

      <View style={styles.spacer} />

      {user && user.userId && (
        <View
          style={{
            alignItems: 'center',
            flexDirection: 'row',
          }}>
          <RegularText styles={styles.title} text={user.userId} />
          <TouchableOpacity onPress={() => logout()}>
            <Image
              source={require('../assets/logo/logout.png')}
              style={styles.icon}
            />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

export default Toolbar;
