import React, {useEffect, useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';

import EdsButton from './Button/EdsButton';

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'black',
    paddingBottom: 24,
  },
  titleTextContainer: {
    paddingHorizontal: 24,
    marginTop: 24,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignContent: 'center',
  },
  subtitleTextContainer: {
    paddingHorizontal: 24,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignContent: 'center',
  },
  titleText: {
    color: 'white',
    fontWeight: 'bold',
  },
  textSubtitle: {
    color: 'white',
  },

  btnContainer: {
    marginTop: 12,
    paddingHorizontal: 24,
  },
});

export interface SerialNoOptionsProps {
  serialNo: string;
  panelNo: number;
  deleteSerialNo(serialNo: string): void;
  hide(): void;
}

const SerialList: React.FC<SerialNoOptionsProps> = ({
  serialNo,
  deleteSerialNo,
  panelNo,
  hide,
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.titleTextContainer}>
        <Text style={styles.titleText}>Delete serial {serialNo}?</Text>
      </View>
      <View style={styles.subtitleTextContainer}>
        <Text style={styles.textSubtitle}>Panel No: {panelNo}</Text>
      </View>
      <View style={styles.btnContainer}>
        <EdsButton
          onPress={() => deleteSerialNo(serialNo)}
          title="Delete"
          color="#1174E6"
          width="100%"
          buttonType="primary"
        />
      </View>

      <View style={styles.btnContainer}>
        <EdsButton
          onPress={() => hide()}
          title="Cancel"
          color="#1174E6"
          width="100%"
          buttonType="secondary"
        />
      </View>
    </View>
  );
};

export default SerialList;
