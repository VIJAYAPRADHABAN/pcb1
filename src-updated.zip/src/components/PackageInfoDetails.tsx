import PackageInfo from '../interfaces/PackageInfo';
import {Alert, FlatList, Text, TouchableOpacity, View} from 'react-native';
import ScanHook from './ScanHook';
import {Symbology} from 'scandit-react-native-datacapture-barcode';
import React, {Dispatch, ReducerAction, useEffect, useState} from 'react';
import {identifiers, removeNonASCII} from './MultiScan/MultiScanHelpers';
import {packageInfoDetailsStyles} from '../assets/componentStyles';
import {BoldText, RegularText} from './Text/RegularText';
import {
  WorkflowAction,
  WorkflowReducerState,
} from '../hooks/reducers/workflowReducer';

export const mandatoryPackageInfoFields: Array<keyof PackageInfo> = [
  'productNo',
  'rState',
  'factoryCode',
  'supplierPartNo',
  'supplierVersion',
  'quantity',
  'manufactureDate',
  'batchNumber',
  'msl',
  'countryCode',
];

export const packageInfoFieldNames: Map<string, string> = new Map([
  ['productNo', 'Product number'],
  ['rState', 'rState'],
  ['factoryCode', 'Factory code'],
  ['supplierPartNo', 'Supplier part no.'],
  ['supplierVersion', 'Supplier version'],
  ['quantity', 'Quantity'],
  ['manufactureDate', 'Manufacture date'],
  ['batchNumber', 'Batch no.'],
  ['msl', 'MSL'],
  ['countryCode', 'Country code'],
]);

export const alertError = (title: string, error: any) => {
  console.log('error:', error);
  Alert.alert(
    title,
    `${error}`,
    [
      {
        text: 'Ok',
      },
    ],
    {
      cancelable: true,
    },
  );
};

export const infoAlert = (
  title: string,
  message: string,
  proceedClicked: (value?: any) => any,
  cancelClicked: (value?: any) => any,
  proceedParameters?: any,
  proceedText: string = 'Proceed',
  cancelText: string = 'Cancel',
) => {
  Alert.alert(
    title,
    message,
    [
      {
        text: cancelText,
        style: 'cancel',
        onPress: () => cancelClicked(),
      },
      {
        style: 'default',
        text: proceedText,
        onPress: () =>
          proceedParameters
            ? proceedClicked(proceedParameters)
            : proceedClicked(),
      },
    ],
    {
      cancelable: false,
    },
  );
};

interface PackageInfoDetailsProps {
  workflowState: WorkflowReducerState;
  dispatch: Dispatch<ReducerAction<any>>;
}

export const PackageInfoDetails = ({
  workflowState,
  dispatch,
}: PackageInfoDetailsProps) => {
  const styles = packageInfoDetailsStyles;
  const {packageFieldToChange, parsedPackageInfo} = workflowState;
  const [singlePanel, setSinglePanel] = useState(true);
  const [multiplePanel, setMultiplePanel] = useState(false);


  const handleSetPackageFieldToChange = (value: keyof PackageInfo | null) => {
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'packageFieldToChange', value: value},
    });
  };

  useEffect(() => {
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'scanDone', value: false},
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'panelType', value: 'SINGLE'},
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'p_type', value: 'SINGLE'},
    });
  }, []);

  const initializeChangeValue = (title: string | null) => {
    if (!title) {
      alertError('Warning', 'Field not found.');
      return;
    }

    infoAlert(
      'Warning',
      `Do you wish to change the value of ${title}`,
      handleSetPackageFieldToChange,
      () => {
        getPackageInfoKeyByName(title);
      },
      () => {},
    );
  };

  const setNewValue = (value: string) => {
    handleSetPackageFieldToChange(null);
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'scanDone', value: false},
    });

    const identifierKey = [...identifiers.keys()].find((key: string) =>
      value.startsWith(key),
    );

    if (!identifierKey) {
      alertError('Warning', 'Please check that the field and value match.');
      return;
    }

    const fieldName = identifiers.get(identifierKey);

    if (fieldName !== packageFieldToChange) {
      alertError('Warning', 'Please check that the field and value match.');
      return;
    }

    const parsedValue = removeNonASCII(value.slice(identifierKey.length));
    const newParsedPackageInfo = {
      ...parsedPackageInfo,
      [`${fieldName}`]: parsedValue,
    } as PackageInfo;

    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'parsedPackageInfo', value: newParsedPackageInfo},
    });
  };

  const getPackageInfoKeyByName = (value: string) => {
    let key = [...packageInfoFieldNames.entries()]
      .filter(({1: v}) => v === value)
      .map(([k]) => k);

    return key ? key[0] : null;
  };

  const parsedValuesToData = (parsedPackageInfo: PackageInfo) => {
    const {
      productNo,
      rState,
      factoryCode,
      supplierPartNo,
      supplierVersion,
      quantity,
      manufactureDate,
      batchNumber,
      msl,
      countryCode,
    } = parsedPackageInfo;

    return [
      {label: 'Product number', data: productNo},
      {label: 'rState', data: rState},
      {label: 'Factory code', data: factoryCode},
      {label: 'Supplier part no.', data: supplierPartNo},
      {label: 'Supplier version', data: supplierVersion},
      {label: 'Quantity', data: quantity},
      {label: 'Manufacture date', data: manufactureDate},
      {label: 'Batch no.', data: batchNumber},
      {label: 'MSL', data: msl},
      {label: 'Country code', data: countryCode},
    ];
  };

  const onePanel = () => {
      setSinglePanel(true);
      setMultiplePanel(false);
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'panelType', value: 'SINGLE'},
      });
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'p_type', value: 'SINGLE'},
      });
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'boardNumberPerPanel', value: 1},
      });
  }

  const manyPanel = () => {
    setSinglePanel(false);
    setMultiplePanel(true);
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'panelType', value: 'SINGLE'},
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'boardType', value: 'SINGLE'},
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'p_type', value: 'MULTI'},
    });
    dispatch({
      type: WorkflowAction.Set,
      payload: {property: 'boardNumberPerPanel', value: '2'},
    });
  }

  if (packageFieldToChange) {
    return (
      <>
        <View>
          <RegularText
            styles={styles.scanningTitle}
            text={`Scanning a new value for ${packageInfoFieldNames.get(
              packageFieldToChange,
            )}`}
          />
        </View>

        <ScanHook
          setCode={setNewValue}
          enableSymbologies={[Symbology.Code128]}
          amountToScan="1"
          continueOnAmountReached={false}
          scanDone={workflowState.scanDone}
        />
      </>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.textContainer}>
        <BoldText text={'Scanned values'} styles={styles.textValue} />
      </View>
      <View style={styles.listContainer}>
        <FlatList
          nestedScrollEnabled
          data={parsedPackageInfo && parsedValuesToData(parsedPackageInfo)}
          renderItem={({item, index}: any) => {
            return (
              <View key={index} style={index % 2 === 0 && styles.oddItem}>
                <TouchableOpacity
                  style={styles.rowItem}
                  onLongPress={() => initializeChangeValue(item.label)}>
                  <RegularText text={item.label} styles={{fontSize: 12}} />

                  <View style={styles.codeCol}>
                    <BoldText
                      text={item.data}
                      styles={{textAlign: 'right', fontSize: 12}}
                    />
                  </View>
                </TouchableOpacity>
              </View>
            );
          }}
          keyExtractor={(item, index) => `${item} ${index}`}
        />
        <View style={{marginBottom:50}}>  
          <Text style={styles.panelTypeText}>Select Panel Type</Text>
          <View style={styles.scanToggleContainer}>
            <TouchableOpacity onPress={onePanel} style={[styles.toggleView,{backgroundColor:singlePanel ? '#0069C2' : '#fff' }]}>
              <Text  style={[styles.toggleText,{color:singlePanel ? '#fff' : '#000' }]}>Single</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={manyPanel} style={[styles.toggleView,{backgroundColor:multiplePanel ? '#0069C2' : '#fff' }]}>
              <Text  style={[styles.toggleText,{color:multiplePanel ? '#fff' : '#000' }]}> Multi </Text>
            </TouchableOpacity>
          </View>
        </View>
        <RegularText text="* Press and hold to rescan single values." />
      </View>
    </View>
  );
};
