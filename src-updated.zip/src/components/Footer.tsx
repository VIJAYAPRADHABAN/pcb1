import React from 'react';
import {View, StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  footer: {
    height: 72,
    backgroundColor: '#0C0C0C',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  buttonHolder: {
    paddingHorizontal: 25,
    paddingVertical: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    flexDirection: 'row',
  },
});

import EdsButton, {ButtonProps} from './Button/EdsButton';

export interface FooterProps {
  footerButtons: ButtonProps[];
}

const Footer: React.FC<FooterProps> = ({
  footerButtons,
}) => {
  return (
    <View style={styles.footer}>
      {footerButtons.map((item,index)=> (
        <View key={index} style={styles.buttonHolder}>
          <EdsButton key={index} {...item}/>
        </View>
      ))}
    </View>
  );
};

export default Footer;
