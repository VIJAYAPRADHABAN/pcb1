import {IOrder} from './useWorkflow';
import {ButtonProps} from '../components/Button/EdsButton';
import {infoAlert} from '../components/PackageInfoDetails';
import PackageInfo from '../interfaces/PackageInfo';
import React, {Dispatch, ReducerAction} from 'react';
import {
  WorkflowAction,
  WorkflowReducerState,
  WorkflowState,
} from './reducers/workflowReducer';
import { Alert } from 'react-native';

interface UseFooterButtonsProps {
  scanPackageClicked: () => void;
  setPackageInfo: (info: PackageInfo | null) => void;
  checkPackageInfoAndValidate: () => void;
  setOrder: React.Dispatch<React.SetStateAction<IOrder | null>>;
  state: WorkflowReducerState;
  dispatch: Dispatch<ReducerAction<any>>;
  setSerialNumbers: (serials: string[]) => void;
  setNextPackageWorkflowState: () => void;
  userLogoutClicked: () => void;
  resetToOrderScan: () => void;
  sendLabelReport: (
    serialNumbers: string[],
    lineNumber: string,
    pi: PackageInfo,
    order: IOrder,
    panelType: string,
    boardType: string,
  ) => void;
}
export const useFooterButtons = ({
  scanPackageClicked,
  setPackageInfo,
  checkPackageInfoAndValidate,
  setOrder,
  state,
  setSerialNumbers,
  dispatch,
  setNextPackageWorkflowState,
  userLogoutClicked,
  resetToOrderScan,
  sendLabelReport,
}: UseFooterButtonsProps) => {
  const {
    packageInfo,
    boardNumberPerPanel,
    order,
    lineNumber,
    allSentSerials,
    panelsSentForPackage,
    serialNumbers,
    serialNoCountToSend,
    okToSendSerials,
    parsedPackageInfo,
    panelType,
    boardType,
    noOfTimesScan,
    p_type
  } = state;
 {console.log('state',state)}

  const handleBoardPerPanelNextClicked = () => {
    let orderQuantity = Number(order?.quantity);
    let packageQuantity = Number(packageInfo?.quantity);
    let infoText = '';
    if(p_type === 'MULTI' ){
      if(Number(boardNumberPerPanel) <= 2){
        let orderQuantity = Number(order?.quantity);
        let packageQuantity = Number(packageInfo?.quantity);
        let quotientValue;
        if(packageQuantity < orderQuantity){
          quotientValue = packageQuantity / Number(2);
        }else{
          quotientValue = orderQuantity / Number(2);
        }
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'noOfTimesScan', value: `${quotientValue}`},
        });
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'boardNumberPerPanel', value:'2'},
        });
      }
      if(Number(boardNumberPerPanel) > Number(packageQuantity) || Number(boardNumberPerPanel) > Number(orderQuantity) ){
        if(packageQuantity < orderQuantity){
          infoText = `Selected board number ${boardNumberPerPanel} is greater than the packageQuantity ${packageQuantity}. Please select the number in range to proceed.`
        }
        if(packageQuantity > orderQuantity){
          infoText = `Selected board number ${boardNumberPerPanel} is greater than the orderQuantity ${orderQuantity}. Please select the number in range to proceed.`
        }
      }
      if(infoText !== ''){
        Alert.alert(
          "Alert",
          infoText,
          [
            {
              text: "Cancel",
              style: "cancel",
            },
          ],
          {
            cancelable: true,
          }
        )
      }else{
        dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.ScanSerials,
        });
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'boardType', value: 'SINGLE'},
        });
        return;
      }
    }else{
      dispatch({
        type: WorkflowAction.UpdateFlow,
        payload: WorkflowState.ScanSerials,
      });
      return;
    }
  };

  const getScanProductNumberButtons = () => {
    if (!parsedPackageInfo) {
      return [
        {
          onPress: () => {
            setOrder(null);
            dispatch({
              type: WorkflowAction.UpdateFlow,
              payload: WorkflowState.OrderNumber,
            });

            dispatch({
              type: WorkflowAction.Set,
              payload: {property: 'scanDone', value: false},
            });
          },
          title: 'Back',
          buttonType: 'secondary',
          width: 147,
        },
        {
          title: 'Done',
          onPress: () => {
            dispatch({
              type: WorkflowAction.Set,
              payload: {property: 'scanDone', value: true},
            });
          },
          buttonType: 'primary',
          width: 147,
        },
      ];
    }

    function onCancelClicked() {
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'packageFieldToChange', value: null},
      });
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'scanDone', value: false},
      });
    }

    function onDoneClicked() {
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'scanDone', value: true},
      });
    }

    function onRescanClicked() {
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'parsedPackageInfo', value: null},
      });

      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'scanDone', value: false},
      });
    }

    function onContinueClicked() {
      checkPackageInfoAndValidate();
    }

    const titles = state.packageFieldToChange
      ? ['Cancel', 'Done']
      : ['Rescan', 'Continue'];
    const actions = state.packageFieldToChange
      ? [onCancelClicked, onDoneClicked]
      : [onRescanClicked, onContinueClicked];

    return [
      {
        buttonType: 'secondary',
        title: titles[0],
        onPress: actions[0],
        width: 147,
      },
      {
        title: titles[1],
        onPress: actions[1],
        width: 147,
        buttonType: 'primary',
      },
    ];
  };

  const getFooterButtons = (state: WorkflowState) => {
    let buttons: ButtonProps[];

    switch (state) {
      case WorkflowState.OrderNumber:
        buttons = [
          {
            onPress: () => {
              scanPackageClicked();
            },
            title: 'Scan package',
            width: 250,
          },
        ];
        break;
      case WorkflowState.ScanProductNumber:
        buttons = getScanProductNumberButtons();
        break;
      case WorkflowState.EnterBoardNumberPerPanel:
        buttons = [
          {
            onPress: () => {
              setPackageInfo(null);
              dispatch({
                type: WorkflowAction.UpdateFlow,
                payload: WorkflowState.ScanProductNumber,
              });
            },
            title: 'Back',
            width: 147,
            buttonType: 'secondary',
          },
          {
            onPress: () => {
              handleBoardPerPanelNextClicked();
            },
            title: 'Scan S/N',
            width: 147,
          },
        ];
        break;
      case WorkflowState.ScanSerials:
        buttons = [
          {
            onPress: () => {
              dispatch({
                type: WorkflowAction.UpdateFlow,
                payload: WorkflowState.SerialList,
              });

              setSerialNumbers([]);

              dispatch({
                type: WorkflowAction.Set,
                payload: {property: 'scanDone', value: false},
              });
            },
            title: 'Cancel',
            width: 250,
            buttonType: 'secondary',
          },
        ];
        break;
      case WorkflowState.SerialList:
        buttons = [
          {
            onPress: () => {
              panelsSentForPackage === Number(noOfTimesScan)
                ? setNextPackageWorkflowState()
                : dispatch({
                    type: WorkflowAction.UpdateFlow,
                    payload: WorkflowState.ScanSerials,
                  });
            },
            title:
              panelsSentForPackage === Number(noOfTimesScan)
                ? 'Scan new package'
                : 'Rescan',
            width: 147,
            buttonType: 'secondary',
          },
          {
            onPress: () => {
              if (panelsSentForPackage === Number(noOfTimesScan)) {
                Alert.alert(
                  "Warning",
                  "You can choose to start a new Compass order if you wish.\n",
                  [
                    {
                      
                      text: "New Order",
                      onPress: () => resetToOrderScan(),
                      
                    },
                    { text: "Logout", 
                      onPress: () => userLogoutClicked()
                    },
                    { text: "Cancel", 
                      
                    },
                    
                  ]
                )
              } else if (packageInfo && order) {
                sendLabelReport(
                  serialNumbers.slice(0, serialNoCountToSend),
                  lineNumber,
                  packageInfo,
                  order,
                  panelType,
                  boardType
                );
              }
            },
            title:
              panelsSentForPackage === Number(noOfTimesScan)
                ? 'Finish Process'
                : `Send`,
            isDisabled:
              panelsSentForPackage !== Number(noOfTimesScan)
                ? !okToSendSerials
                : false,
            width: 147,
          },
        ];
        break;
      default:
        buttons = [];
    }

    return buttons;
  };

  return {
    getFooterButtons,
  };
};