import {alertError} from '../components/PackageInfoDetails';
import User from '../interfaces/User';

enum LogType {
  Error = 'error',
  Warning = 'warning',
  Info = 'info',
}

export interface Logging {
  sendErrorLog: (error: string) => void;
  sendWarningLog: (error: string) => void;
  sendInfoLog: (error: string) => void;
}

const send = async (
  type: LogType,
  message: string,
  endpoint: string,
  user: User | null,
) => {
  const url = `${endpoint}/log/${type}?message="username": "${user?.userId}", ${message}`;
  let headers = {
    Accept: 'application/json',
  };
  fetch(url, {
    method: 'POST',
    headers,
  }).catch(err =>
    alertError(
      'Error',
      `Logging failed. Please contact support. Error: ${err}`,
    ),
  );
};

export const useLogging = (endpoint: string, user: User | null): Logging => {
  return {
    sendErrorLog: (error: string) => {
      if (!endpoint) {
        return;
      }
      send(LogType.Error, error, endpoint, user);
    },
    sendWarningLog: (error: string) => {
      if (!endpoint) {
        return;
      }
      send(LogType.Warning, error, endpoint, user);
    },
    sendInfoLog: (error: string) => {
      if (!endpoint) {
        return;
      }
      send(LogType.Info, error, endpoint, user);
    },
  };
};
