import React, { Dispatch, ReducerAction, useEffect, useState } from 'react';
import { authorize, refresh } from 'react-native-app-auth';
import { Alert } from 'react-native';

import User from '../interfaces/User';

import AsyncStorage from '@react-native-async-storage/async-storage';
import jwt_decode from 'jwt-decode';
import Token from '../interfaces/token';
import { useLogging } from './useLogging';
import Settings from '../interfaces/Settings';
import {
  WorkflowAction,
  workflowReducerInitialState,
  WorkflowReducerState,
  WorkflowState,
} from './reducers/workflowReducer';
import { infoAlert } from '../components/PackageInfoDetails';
import { isEqual } from 'lodash';

interface UseAuthResult {
  user: User | null;
  logout: () => void;
  jwt: string | null;
  login: (idToken: string) => void;
  isTokenRefreshNeeded: () => boolean;
  refreshToken: () => void;
}


const errorAlert = (topic: string, error: any) => {
  Alert.alert(
    topic,
    `${error}`,
    [
      {
        text: 'Ok',
      },
    ],
    {
      cancelable: true,
    },
  );
};

export const saveStateToStorage = async (
  workflowState: WorkflowReducerState | null,
) => {
  console.log('Saving state', workflowState);
  try {
    await AsyncStorage.setItem(
      'WORKFLOW_STATE',
      workflowState ? JSON.stringify(workflowState) : '',
    );
  } catch (error) {
    console.log('error storing settings', error);
  }
};

const getPreviousState = async () => {
  return await AsyncStorage.getItem('WORKFLOW_STATE');
};

const handleSessionChange = async (
  state: WorkflowReducerState,
  dispatch: Dispatch<ReducerAction<any>>,
) => {
  const prevState = await getPreviousState();
  console.log('prevState', !prevState, prevState);
  if (!prevState) {
    return;
  }

  const prevStateForComparison = {
    ...JSON.parse(prevState),
    previous: WorkflowState.Unauthenticated,
    current: WorkflowState.Unauthenticated,
  };

  const initialState = {
    ...workflowReducerInitialState,
    previous: WorkflowState.Unauthenticated,
    current: WorkflowState.Unauthenticated,
  };

  if (prevState && !isEqual(prevStateForComparison, initialState)) {
    infoAlert(
      'Alert',
      'Previous session data registered. Do you wish to restore previous session workflow?',
      () => {
        dispatch({
          type: WorkflowAction.RestoreSession,
          payload: JSON.parse(prevState),
        });
      },
      () => { },
      [],
      'Restore',
      'Cancel',
    );
  }
};

export const useAuth = (
  settings: Settings,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  state: WorkflowReducerState,
  dispatch: Dispatch<ReducerAction<any>>,
): UseAuthResult => {
  const [jwt, setJwt] = useState<string | null>(null);
  const [ep, setEp] = useState<string>('');
  const [user, setUser] = useState<User | null>(null);
  const { sendErrorLog, sendInfoLog } = useLogging(settings.endpoint, user);

  // const { instance, accounts } = authorize();



  useEffect(() => {
    setEp(settings.authEndpoint);
  }, [settings]);

  useEffect(() => {
    retrieveToken();
  }, []);

  const retrieveToken = async () => {
    try {
      const value = await AsyncStorage.getItem('TOKEN');

      if (value) {
        const jwt: string = JSON.parse(value);
        if (checkTokenRemainingTime(jwt) <= 0) {
          handleTokenExpired();
          return;
        }
        decodeAndStoreJwt(jwt);
      }
    } catch (error) {
      sendErrorLog(`"message": "error retrieving jwt: ${error}"`);
    }
  };

  const storeToken = async (jwt: string) => {
    try {
      await AsyncStorage.setItem('TOKEN', JSON.stringify(jwt));
    } catch (error) {
      sendErrorLog(`"message": "error storing jwt: ${error}"`);
    }
  };

  const logout = () => {
    sendInfoLog(`"message": "logged out"`);
    setJwt(null);
    storeToken('');
    setUser(null);
  };

  const login = async (idToken: string) => {
    setIsLoading(true);

    try {
      let _user = decodeAndStoreJwt(idToken);
      handleSessionChange(state, dispatch);
      useLogging(settings.endpoint, _user).sendInfoLog(
        `"message": "logged in with Azure Entra ID"`,
      );
    } catch (err) {
      let errMessage = err;
      if (err instanceof Error) {
        errMessage = err.message;
        sendErrorLog(`"message": "${err.message}"`);
      }
      errorAlert('Failed to log in', errMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshToken = () => {
    const url = `${ep}/auth/refreshtoken`;
    let headers = {
      Accept: 'application/json',
      Authorization: `${jwt}`,
    };
    fetch(url, {
      method: 'get',
      headers,
    })
      .then(res => {
        if (res.status == 401) {
          throw Error('User credentials expired. Please log in');
        } else if (!res.ok) {
          throw Error(
            `Server error. StatusCode ${res.status}. Please contact support if problem remains.`,
          );
        } else {
          return res.json();
        }
      })
      .then(jwt => decodeAndStoreJwt(jwt))
      .catch(err => {
        let errMessage = err;
        if (err instanceof Error) {
          //TODO: handle possible Timeout, Network request failed
          errMessage = err.message;
        }
        sendErrorLog(`"message": "Failed to refresh token ${errMessage}"`);
        errorAlert('Failed to refresh token:', errMessage);
      });
  };

  const decodeAndStoreJwt = (jwt: string): User => {
    try {
      const jwtObj = jwt_decode<Token>(jwt);
      const roles = jwtObj.role
        ? Array.isArray(jwtObj.role)
          ? jwtObj.role
          : [jwtObj.role]
        : [];
      const _user: User = {
        userId: jwtObj.unique_name,
        roles,
      };
      handleSuccessfulJwtDecode(jwt, _user);
      return _user;
    } catch (err) {
      throw Error(`Failed to decode and store credentials with error: ${err}`);
    }
  };

  const handleSuccessfulJwtDecode = (jwt: string, user: User) => {
    setJwt(jwt);
    setUser(user);
    storeToken(jwt);
  };

  const isTokenRefreshNeeded = (): boolean => {
    if (jwt == null || jwt == '') {
      return false;
    }
    try {
      const remainingMin = checkTokenRemainingTime(jwt);
      if (remainingMin < 0) {
        handleTokenExpired();
      } else if (remainingMin < 5) {
        return true;
      }
      return false;
    } catch (err) {
      sendErrorLog(`"message": "error in isTokenRefreshNeeded: ${err}"`);
      return false;
    }
  };

  const checkTokenRemainingTime = (token: string): Number => {
    const tokenObj = jwt_decode<Token>(token);

    const now = new Date();
    const tokenExp = new Date(tokenObj.exp * 1000);
    const remainingMin = (tokenExp.getTime() - now.getTime()) / 1000 / 60;
    return remainingMin;
  };

  const handleTokenExpired = () => {
    saveStateToStorage(state);
    errorAlert('Warning', 'User credentials expired. Please log in');
    logout();
  };

  return {
    user,
    jwt,
    login,
    logout,
    isTokenRefreshNeeded,
    refreshToken,
  };
};
