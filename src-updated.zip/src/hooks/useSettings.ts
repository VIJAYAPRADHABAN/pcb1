import Settings from '../interfaces/Settings';
import {useEffect, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {alertError} from '../components/PackageInfoDetails';

export const useSettings = () => {
  const _settings: Settings = {
    endpoint: '',
    authEndpoint: '',
    alternativeReportEndpointEnabled: false,
  };

  const [settings, setSettings] = useState<Settings>(_settings);
  const [isLoadingSettings, setIsLoadingSettings] = useState<boolean>(false);

  const retrieveSettings = async () => {
    try {
      setIsLoadingSettings(true);
      const value = await AsyncStorage.getItem('SETTINGS');
      if (value !== null) {
        const obj: Settings = JSON.parse(value);
        setSettings(obj);
      }
    } catch (error) {
      alertError(
        'ERROR',
        `Failed to retrieve settings. Please contact an administrator. ${error}`,
      );
    } finally {
      setIsLoadingSettings(false);
    }
  };

  const storeSettings = async (settings: Settings) => {
    try {
      await AsyncStorage.setItem('SETTINGS', JSON.stringify(settings));
    } catch (error) {
      console.log('error storing settings', error);
    }
  };

  const saveSettings = (settings: Settings) => {
    setSettings(settings);
    storeSettings(settings);
  };

  return {
    isLoadingSettings,
    settings,
    saveSettings,
    retrieveSettings,
  };
};
