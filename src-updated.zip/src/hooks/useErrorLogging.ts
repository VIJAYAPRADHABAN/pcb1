enum LogType {
  Error = 'error',
  Warning = 'warning',
  Info = 'info',
}

const send = async (type: LogType, error: string, endpoint: string | null) =>
  new Promise<any>((resolve, reject) => {
    const url = `${endpoint}/log/${type}?message=${error}`;

    let headers = {
      Accept: 'application/json',
    };
    fetch(url, {
      method: 'POST',
      headers,
    }).catch(err => {
      if (err instanceof Error) {
        reject(err.message);
      } else {
        reject(err);
      }
    });
  });

export const useErrorLogging = (endpoint: string) => {
  return {
    sendErrorLog: (error: string) => {
      if (!endpoint) {
        return;
      }
      send(LogType.Error, error, endpoint);
    },
    sendWarningLog: (error: string) => {
      if (!endpoint) {
        return;
      }
      send(LogType.Warning, error, endpoint);
    },
    sendInfoLog: (error: string) => {
      if (!endpoint) {
        return;
      }
      send(LogType.Info, error, endpoint);
    },
  };
};
