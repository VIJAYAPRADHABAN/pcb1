import {Dispatch, ReducerAction, useEffect} from 'react';
import Settings from '../interfaces/Settings';
import PackageInfo from './../interfaces/PackageInfo';
import {hasSuperUserPermissions} from '../components/Login';
import User from '../interfaces/User';
import {
  WorkflowAction,
  WorkflowReducerState,
  WorkflowState,
} from './reducers/workflowReducer';
import ScanResult from '../interfaces/ScanResult';
import {filterScanned} from '../components/MultiScan/MultiScanHelpers';
import {Logging} from './useLogging';
import {saveStateToStorage} from './useAuth';

export interface IOrder {
  orderId: string;
  orderType: string;
  recipeId: string;
  recipeRevision: string;
  recipeStatus: string;
  productNumber: string;
  productRevision: string;
  quantity: string;
  orderStatus: string;
  productionLine: string;
  priority: string;
  errorCode: string;
  errorDomain: string;
  errorMessage: string;
}

export const useWorkflow = (
  settings: Settings,
  jwt: any,
  user: User | null,
  logging: Logging,
  state: WorkflowReducerState,
  dispatch: Dispatch<ReducerAction<any>>,
) => {
  const resetSerialsData = (soft: boolean = false) => {
    const newValues = [
      {property: 'sentSerialNumbersForPackage', value: []},
      {property: 'panelsSentForPackage', value: 0},
      {property: 'okToSendSerials', value: false},
      {property: 'serialNoCountToSend', value: 0},
    ];

    newValues.forEach((payload: any) => {
      dispatch({type: WorkflowAction.Set, payload: payload});
    });

    soft
      ? dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'serialNumbers', value: []},
        })
      : dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'allSentSerials', value: []},
        });
  };

  useEffect(() => {
    if (
      state.boardNumberPerPanel.length &&
      !isNaN(parseInt(state.boardNumberPerPanel)) &&
      state.packageInfo
    ) {
      dispatch({
        type: WorkflowAction.Set,
        payload: {
          property: 'serialNoCountToSend',
          value: parseInt(state.boardNumberPerPanel),
        },
      });
    }
  }, [state.packageInfo, state.boardNumberPerPanel]);

  const appendSerialNumbers = (serials: ScanResult[]) => {
    const {serialNumbers, sentSerialNumbersForPackage} = state;
    try {
      const filteredSerials = filterScanned(
        serials,
        serialNumbers,
        sentSerialNumbersForPackage,
      );

      dispatch({
        type: WorkflowAction.Set,
        payload: {
          property: 'serialNumbers',
          value: [...serialNumbers, ...filteredSerials],
        },
      });
      dispatch({
        type: WorkflowAction.UpdateFlow,
        payload: WorkflowState.SerialList,
      });
    } catch (error) {
      logging.sendErrorLog(
        `"message": "error on scan serials ${error}. New serials: ${encodeURIComponent(
          JSON.stringify(serials),
        )}, serial numbers ${serialNumbers.join(', ')}, 
        sent serial numbers  ${sentSerialNumbersForPackage.join(', ')}"`,
      );
    }
  };

  const resetWorkflow = () => {
    dispatch({
      type: WorkflowAction.ResetWorkflow,
    });
  };

  const resetWorkflowForNextPackage = () => {
    dispatch({
      type: WorkflowAction.ResetWorkflowForNextPackage,
    });
  };

  const userLogout = () => {
    dispatch({type: WorkflowAction.Logout});
  };

  const updateWorkflow = async () => {
    const currentWorkFlowState = state.current;

    if (!jwt) {
      if (settings.authEndpoint?.length == 0) {
        console.log('should go settings');
        await dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.Settings,
        });
      } else if (currentWorkFlowState !== WorkflowState.Unauthenticated) {
        console.log('should go logout');

        await dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.Unauthenticated,
        });
      }
    } else {
      if (
        user &&
        hasSuperUserPermissions(user) &&
        settings.endpoint.length == 0
      ) {
        console.log('should go settings 2');
        dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.Settings,
        });
      }

      if (
        currentWorkFlowState !== WorkflowState.OrderNumber &&
        !state.order &&
        settings.endpoint.length > 0 &&
        settings.authEndpoint.length > 0
      ) {
        dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.OrderNumber,
        });
      } else if (
        currentWorkFlowState !== WorkflowState.Settings &&
        (!settings || settings.endpoint.length == 0)
      ) {
        dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.Settings,
        });
      }
    }
  };

  useEffect(() => {
    if (
      state.current == WorkflowState.Unknown ||
      state.current == WorkflowState.Unauthenticated
    ) {
      updateWorkflow();
    }
  }, [state]);

  useEffect(() => {
    updateWorkflow();
  }, [jwt]);

  return {
    workflowState: state,
    dispatch,
    setSerialNumbers: (serials: any[]) => {
      dispatch({
        type: WorkflowAction.Set,
        payload: {property: 'serialNumbers', value: serials},
      });

      if (
        state.boardNumberPerPanel &&
        state.serialNumbers.length === Number(state.boardNumberPerPanel)
      ) {
        dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.SerialList,
        });
      }
    },
    setOrder: (order: any) => {
      if (order) {
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'order', value: order},
        });
        dispatch({
          type: WorkflowAction.UpdateFlow,
          payload: WorkflowState.ScanProductNumber,
        });
      }
    },
    setPackageInfo: (info: PackageInfo | null) => {
      if (info) {
        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'packageInfo', value: info},
        });

        dispatch({
          type: WorkflowAction.Set,
          payload: {property: 'scanDone', value: false},
        });
        if(!state.packageInfo
          || state.packageInfo?.productNo !== info.productNo) {
            dispatch({
              type: WorkflowAction.UpdateFlow,
              payload: WorkflowState.EnterBoardNumberPerPanel,
            });
            dispatch({
              type: WorkflowAction.Set,
              payload: {property: 'boardNumberPerPanel', value: "1"},
            });
        }
        else {
          dispatch({
            type: WorkflowAction.UpdateFlow,
            payload: WorkflowState.ScanSerials,
          });
        }
      }
    },
    resetWorkflow,
    resetWorkflowForNextPackage,
    userLogout,
    resetSerialsData,
    appendSerialNumbers,
    saveStateToStorage,
  };
};