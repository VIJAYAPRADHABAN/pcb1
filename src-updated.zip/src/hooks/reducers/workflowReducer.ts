import {IOrder} from '../useWorkflow';
import PackageInfo from '../../interfaces/PackageInfo';

export enum WorkflowState {
  Unauthenticated = 'unauthenticated',
  Settings = 'settings',
  OrderNumber = 'orderNumber',
  ScanProductNumber = 'scanProductNumber',
  EnterBoardNumberPerPanel = 'enterBoardNumberPerPanel',
  ScanSerials = 'scanSerials',
  SerialList = 'serialList',
  Unknown = 'unknown',
}

export enum WorkflowAction {
  UpdateFlow = 'UpdateFlow',
  Logout = 'Logout',
  ResetWorkflow = 'ResetWorkflow',
  ResetWorkflowForNextPackage = 'ResetWorkflowForNextPackage',
  Panel = 'Panel',
  Set = 'Set',
  RestoreSession = 'RestoreSession',
}

export interface WorkflowReducerState {
  current: WorkflowState;
  previous: WorkflowState;
  order: IOrder | null;
  boardNumberPerPanel: string;
  lineNumber: string;
  orderNumber: string;
  noOfTimesScan: number | null;
  packageInfo: PackageInfo | null;
  packageFieldToChange: keyof PackageInfo | null;
  serialNumbers: string[];
  serialNoCountToSend: number;
  okToSendSerials: boolean;
  allSentSerials: string[];
  sentSerialNumbersForPackage: string[];
  panelsSentForPackage: number;
  parsedPackageInfo: PackageInfo | null;
  scanDone: boolean;
  panelType: string;
  boardType: string;
  p_type:string;
}

export const workflowReducerInitialState = {
  current: WorkflowState.Unknown,
  previous: WorkflowState.Unknown,
  order: null,
  boardNumberPerPanel: '1',
  noOfTimesScan:null,
  panelType:'',
  boardType : '',
  lineNumber: '1',
  orderNumber: '',
  packageInfo: null,
  packageFieldToChange: null,
  serialNumbers: [],
  serialNoCountToSend: 0,
  okToSendSerials: false,
  allSentSerials: [],
  sentSerialNumbersForPackage: [],
  panelsSentForPackage: 0,
  parsedPackageInfo: null,
  scanDone: false,
  p_type:'',
};

const handleSettingWorkflowProperty = (
  prevState: WorkflowReducerState,
  payload: {property: keyof PackageInfo; value: any},
) => {
  return {...prevState, [payload.property]: payload.value};
};

export function workflowReducer(
  prevState: WorkflowReducerState,
  {type, payload}: any,
): WorkflowReducerState {
  switch (type) {
    case WorkflowAction.UpdateFlow:
      return {
        ...prevState,
        current: payload,
        previous: prevState.current,
      };
    case WorkflowAction.Logout:
      return {
        ...workflowReducerInitialState,
        previous: prevState.current,
      };
    case WorkflowAction.ResetWorkflow:
      return {
        ...prevState,
        previous: prevState.current,
        current: WorkflowState.ScanProductNumber,
        boardNumberPerPanel: '1',
        noOfTimesScan: null,
        panelType: '',
        boardType : '',
        packageInfo: null,
        packageFieldToChange: null,
        parsedPackageInfo: null,
        scanDone: false,
      };
    case WorkflowAction.ResetWorkflowForNextPackage:
        return {
          ...prevState,
          previous: prevState.current,
          current: WorkflowState.ScanProductNumber,
          packageFieldToChange: null,
          parsedPackageInfo: null,
          scanDone: false,
        };
    case WorkflowAction.Set:
      return handleSettingWorkflowProperty(prevState, payload);
    case WorkflowAction.RestoreSession:
      return payload;
    default:
      throw new Error();
  }
}