import ProductionOrderResponse from '../interfaces/ProductionOrderResponse';
import ProdOrderNonSerializedMaterialValidateInput from '../interfaces/ProdOrderNonSerializedMaterialValidateInput';
import {
  alertError,
  infoAlert,
  mandatoryPackageInfoFields,
  packageInfoFieldNames,
} from '../components/PackageInfoDetails';
import PackageInfo from '../interfaces/PackageInfo';
import Settings from '../interfaces/Settings';

interface ProdOrderNonSerializedMaterialValidateResult {
  checkPackageInfoAndValidate: () => void;
}

export const useProdOrderNonSerializedMaterialValidate = (
  parsedPackageInfo: PackageInfo | null,
  orderNumber: string,
  settings: Settings,
  jwt: any,
  setIsLoading: any,
  setPackageInfo: any,
  logging: {
    sendErrorLog: (error: string) => void;
    sendWarningLog: (error: string) => void;
    sendInfoLog: (error: string) => void;
  },
): ProdOrderNonSerializedMaterialValidateResult => {
  const validateCode = () => {
    if (!parsedPackageInfo) {
      alertError('Error', 'Package info is missing!');
      return;
    }

    const input: ProdOrderNonSerializedMaterialValidateInput = {
      productNumber: parsedPackageInfo.productNo,
      productionOrderNo: orderNumber,
      rState: parsedPackageInfo.rState,
    };

    setIsLoading(true);

    validateProdOrder(settings.endpoint, jwt, input)
      .then(res => {
        if (!res.isValid) {
          logging.sendWarningLog(
            `"query": "${encodeURIComponent(query(input))}", "message": "${
              res.errorMessage
            }"`,
          );
          alertError('Warning', res.errorMessage);
        } else {
          setPackageInfo(parsedPackageInfo);
        }
      })
      .catch(err => {
        var errorMessage = `Failed to validate production order: ${err}`;
        logging.sendErrorLog(`"message": "${errorMessage}"`);
        alertError('Error', errorMessage);
      })
      .finally(() => setIsLoading(false));
  };

  const checkBeforeValidationAlert = () => {
    if (!parsedPackageInfo) {
      alertError('Error', 'Package info is missing!');
      return;
    }

    let missingFields = [] as string[];
    mandatoryPackageInfoFields.forEach(key => {
      if (!parsedPackageInfo[key]) {
        const name =
          packageInfoFieldNames.has(key) && packageInfoFieldNames.get(key);
        if (name) {
          missingFields.push(name);
        }
      }
    });

    if (missingFields.length) {
      const message = `The value${
        missingFields.length > 1 ? 's' : ''
      } of mandatory field${
        missingFields.length > 1 ? 's' : ''
      }: ${missingFields.join(', ')} are missing. Make sure that ${
        missingFields.length > 1 ? 'these fields are' : 'this field is'
      } not specified of scan again.`;

      infoAlert('Warning', message, validateCode, () => {});
      return;
    } else {
      validateCode();
    }
  };

  const query = (input: ProdOrderNonSerializedMaterialValidateInput) => {
    const params = {
      ...input,
    };
    return `?productNumber=${encodeURIComponent(
      params.productNumber,
    )}&productionOrderNo=${encodeURIComponent(
      params.productionOrderNo,
    )}&rState=${encodeURIComponent(params.rState)}`;
  };

  const validateProdOrder = async (
    endpoint: string,
    jwt: string,
    input: ProdOrderNonSerializedMaterialValidateInput,
  ) =>
    new Promise<ProductionOrderResponse>((resolve, reject) => {
      const url = `${endpoint}/invoke/I200121ProdOrderNonSerializedMaterialValidate.imp.c1.services:ProductionOrderNonSerializedMaterialValidate`;
      const uri = `${url}${query(input)}`;

      let headers = {
        Accept: 'application/json',
        Authorization: `${jwt}`,
      };
      fetch(uri, {
        method: 'GET',
        headers,
      })
        .then(res => {
          if (!res.ok) {
            var errorMessage = `Server error. StatusCode ${res.status}. Please contact support if problem remains.`;
            reject(errorMessage);
          } else {
            resolve(res.json());
          }
        })
        .catch(err => {
          if (err instanceof Error) {
            //TODO: handle possible Timeout, Network request failed
            reject(err.message);
            logging.sendErrorLog(`"message": "${err.message}"`);
          } else {
            reject(err);
            logging.sendErrorLog(`"message": "${err}"`);
          }
        });
    });

  return {checkPackageInfoAndValidate: checkBeforeValidationAlert};
};
