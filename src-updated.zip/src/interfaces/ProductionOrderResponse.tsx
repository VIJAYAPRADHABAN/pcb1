export default interface ProductionOrderResponse {
  isValid: boolean;
  errorMessage: string;
  errorDomain: string;
  errorCode: string;
}
