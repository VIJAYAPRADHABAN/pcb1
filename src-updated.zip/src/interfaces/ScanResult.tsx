export default interface ScanResult {
  data: string;
  type: string;
}
