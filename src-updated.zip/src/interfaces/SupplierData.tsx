export default interface SupplierData {
  ProductNo: string;
  RState: string;
  SupplierCode: string;
  SupplierPartNo: string;
  SupplierRev: string;
  MadeIn: string;
  ManufacturedDate: string;
  BatchNo: string;
  MSL: string;
}
