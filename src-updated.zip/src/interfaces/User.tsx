export default interface User {
  userId: string;
  roles: string[];
}
