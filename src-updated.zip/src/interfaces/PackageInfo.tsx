export default interface PackageInfo {
  productNo: string;
  rState: string;
  factoryCode: string;
  supplierPartNo: string;
  supplierVersion: string;
  quantity: string;
  manufactureDate: string;
  batchNumber: string;
  msl: string;
  countryCode: string;
}
