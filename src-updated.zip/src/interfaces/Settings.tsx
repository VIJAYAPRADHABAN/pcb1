export default interface Settings {
  endpoint: string;
  authEndpoint: string;
  alternativeReportEndpointEnabled: boolean;
}
