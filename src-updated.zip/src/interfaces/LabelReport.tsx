import TraceData from './TraceData';
import SupplierData from './SupplierData';

export default interface LabelReport {
  Program: string;
  TimeDone: string;
  Equipment: string;
  SupplierData: SupplierData;
  TraceData: TraceData;
  Panel: string
}
