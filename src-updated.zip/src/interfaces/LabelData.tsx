export default interface LabelData {
  ArrayID: string;
  Serialnumber: string;
}
