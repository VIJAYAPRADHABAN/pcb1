import {StyleSheet} from 'react-native';

export const orderNumberStyled = StyleSheet.create({
  textStyles: {
    marginTop: 32,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    backgroundColor: '#EBEBEB',
    fontFamily: 'EricssonHilda-Regular',
  },
  lineNumberButton: {
    padding: 0,
    borderWidth: 1,
    borderRadius: 3,
    height: 32,
    width: 32,
  },
  input: {
    fontFamily: 'EricssonHilda-Regular',
    fontSize: 14,
    color: 'black',
    borderColor: '#878787',
    height: 40,
    borderWidth: 1,
    minWidth: 40,
    backgroundColor: 'white',
    paddingLeft: 6,
  },
  lineNumberInput: {
    fontFamily: 'EricssonHilda-Regular',
    fontSize: 14,
    borderColor: '#878787',
    height: 32,
    padding: 0,
    borderWidth: 1,
    minWidth: 32,
    textAlign: 'center',
    backgroundColor: 'white',
    marginHorizontal: 16,
    color: '#242424',
  },
  addText: {
    color: 'black',
    marginHorizontal: 11,
    marginVertical: 4,
    width: '100%',
  },
  minusText: {
    color: 'black',
    marginHorizontal: 12,
    marginVertical: 4,
    fontWeight: 'bold',
    width: '100%',
  },
});

export const serialListStyles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    backgroundColor: '#EBEBEB',
  },
  textContainer: {
    marginTop: 32,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignContent: 'center',
    flexWrap: 'wrap',
  },
  textColumn: {
    flex: 2,
  },
  textValue: {
    fontWeight: 'bold',
  },
  listContainer: {
    paddingTop: 24,
    flex: 1,
    alignSelf: 'center',
    width: '100%',
  },
  rowItem: {
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'center',
  },
  indexCol: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
    margin: 12,
  },
  codeCol: {flex: 2, justifyContent: 'center', padding: 10},
  oddItem: {
    flex: 1,
    backgroundColor: '#EBEBEB',
  },
  evenItem: {
    flex: 1,
    backgroundColor: '#DCDCDC',
  },
  icon: {
    width: 16,
    height: 16,
    margin: 16,
  },
  headerBox:{
    flexDirection: 'row',
    marginRight: 12,
    marginVertical:10,
  },
  sortIcon: {
    marginHorizontal:6,
  }
});

export const amountOfBoardsStyles = StyleSheet.create({
  textStyles: {
    textAlign: 'center',
    marginTop: 32,
    marginBottom: 16,
    fontWeight: 'bold',
  },
  container: {
    justifyContent: 'center',
    paddingHorizontal: 24,
    backgroundColor: '#EBEBEB',
  },
  amountOfBoardsLine: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignContent: 'center',
    alignSelf: 'center',
  },
  infoLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'space-between',
    fontSize: 14,
  },
  packageInfoContainer: {
    backgroundColor: 'white',
    flexDirection: 'column',
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  lineNumberButton: {
    padding: 0,
    borderWidth: 1,
    borderRadius: 3,
    height: 32,
    width: 32,
  },
  input: {
    fontFamily: 'EricssonHilda-Regular',
    textAlign: 'center',
    color: 'black',
    borderColor: '#878787',
    height: 32,
    padding: 0,
    borderWidth: 1,
    minWidth: 32,
    backgroundColor: 'white',
    marginHorizontal: 16,
  },
  addText: {
    color: 'black',
    marginHorizontal: 11,
    marginVertical: 4,
    width: '100%',
  },
  minusText: {
    color: 'black',
    marginHorizontal: 12,
    marginVertical: 4,
    fontWeight: 'bold',
    width: '100%',
  },
  scanToggleContainer:{
    flexDirection:'row',
    backgroundColor:'white',
    alignSelf:'center',
    justifyContent:'space-between',
    marginTop:30,
    borderRadius:10,
  },
  selectedTextStyle:{
    textAlign:'center',
    color:'#fff',
    fontWeight:'bold'
  },
  unselectedTextStyle:{
    textAlign:'center',
    color:'#000',
    fontWeight:'bold'
  },
  selectedViewStyle:{
    backgroundColor:'#0069C2',
     borderRadius:10, 
     padding:10
  },
  unselectedViewStyle:{
    backgroundColor:'#fff',
    borderRadius:10, 
    padding:10
  },
  selectedTile:{
    backgroundColor:'#0069C2',
    borderColor:'#000',
    width:40,
    height:40,
    borderWidth:1,
    margin:5,   
    borderRadius:5,
    justifyContent:'center'
  },
  unselectedTile:{
    backgroundColor:'#fff',
    borderColor:'#000',
    width:40,
    height:40,
    borderWidth:1,
    margin:5,
    borderRadius:5,
    justifyContent:'center'
  }
});

export const packageInfoDetailsStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EBEBEB',
  },
  textContainer: {
    paddingHorizontal: 24,
    marginTop: 32,
    flexDirection: 'row',
    alignContent: 'center',
    justifyContent: 'center'
  },
  textColumn: {
    flex: 2,
  },
  textValue: {
    alignSelf: 'center',
    fontSize: 14,
  },
  listContainer: {
    padding: 24,
    flex: 1,
    alignSelf: 'center',
    width: '100%',
  },
  rowItem: {
    flexDirection: 'row',
    padding: 6,
    flex: 1,
  },
  codeCol: {
    flex: 1,
    justifyContent: 'center'},
  oddItem: {
    flex: 1,
    backgroundColor: '#DCDCDC',
  },
  continueButton: {
    marginTop: 24,
    paddingHorizontal: 0,
    alignItems: 'center',
    justifyContent: 'space-between',
    flex: 1,
    flexDirection: 'row',
  },
  tipText: {
    fontSize: 14,
    fontWeight: 'normal',
    color: '#f5f7f9',
  },
  scanningTitle: {
    fontSize: 16,
    color: 'black',
    alignSelf: 'center',
  },
  snackbar: {
    paddingHorizontal: 24,
    marginTop: 20,
    marginHorizontal: 10,
    paddingVertical: 16,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    color: 'white',
    backgroundColor: '#0069C2',
  },
  icon: {
    width: 24,
    height: 24,
  },
  iconContainer: {
    width: 24,
    height: 24,
  },
  panelTypeText:{
    fontSize:18,
    fontWeight:'bold',
    color:'#000',
    textAlign:'center'
  },
  scanToggleContainer:{
    flexDirection:'row',
    backgroundColor:'white',
    alignSelf:'center',
    justifyContent:'space-between',
    marginTop:10,
    borderRadius:10,
  },
  toggleView:{
    borderRadius:10, 
    padding:10
  },
  toggleText:{
    textAlign:'center',
    fontWeight:'bold'
  },
});
