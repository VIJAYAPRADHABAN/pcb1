import * as React from 'react';
import {SvgXml} from 'react-native-svg';

export const ChevronDownIcon = ({
  fill,
  width,
  height,
  styles,
}: {
  fill: string;
  height: number;
  width: number;
  styles?: any;
}) => {
  const xml = `
<svg width="${width}" height="${height}" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.00302 9.147L4.35602 5.5L3.65002 6.206L8.00302 10.559L12.355 6.206L11.65 5.5L8.00302 9.147Z" fill="${fill}"/>
</svg>
`;

  return <SvgXml style={styles} xml={xml} />;
};
