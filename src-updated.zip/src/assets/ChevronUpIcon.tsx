import * as React from 'react';
import {SvgXml} from 'react-native-svg';

export const ChevronUpIcon = ({
  fill,
  width,
  height,
  styles,
}: {
  fill: string;
  height: number;
  width: number;
  styles?: any;
}) => {
  const xml = `
<svg width="${width}" height="${height}" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.00302 5.44L3.65002 9.793L4.35602 10.498L8.00302 6.852L11.65 10.498L12.355 9.793L8.00302 5.44Z" fill="${fill}"/>
</svg>
`;

  return <SvgXml style={styles} xml={xml} />;
};
