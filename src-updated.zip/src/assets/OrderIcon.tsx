import * as React from 'react';
import {SvgXml} from 'react-native-svg';

export const OrderIcon = ({
  fill,
  width,
  height,
  styles,
}: {
  fill: string;
  height: number;
  width: number;
  styles: any;
}) => {
  const xml = `
<svg width="${width}" height="${height}" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M8 5.50002L4 0.166687L0 5.50002H8ZM4 1.83302L6 4.50002H2L4 1.83302ZM0 8.50002L4 13.8334L8 8.50002H0ZM4 12.167L6 9.50002H2L4 12.167Z" fill="${fill}"/>
</svg>
`;

  return <SvgXml style={styles} xml={xml} />;
};
